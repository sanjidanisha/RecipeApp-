This is all the code I worked on at Purewow with my team.

I was mainly focused on the Filter Screen and the All Screen. 

If you have any questions, feel free to email me at villaveraerik@gmail.com

If you want to see a video of the final product please click here. 

https://drive.google.com/file/d/1c5A6ooF6l5BODMYszxslEGIXYxNbMv-M/view?usp=sharing
