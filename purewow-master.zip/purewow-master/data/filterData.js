var filterData = [
  {
    "title": "Time",
		"subcategories": ["30 mins or less", "30 mins - 1 hour","1 hour - 3 hours","3 hours +"],
    "times" : [30, 60, 180, 500],
    "index" : 0,
  },
  {
  "title" : "Main Protein",
  "subcategories" : ["Chicken", "Beef","Pork","Eggs","Beans","Soy & Tofu","Fish & Seafood"],
  "index" : 1
  },
  {
  "title" : "Type Of Diet",
  "subcategories" : ["Ketogenic","Vegan","Atkins","Pescatarian","Gluten Free","Dairy Free",
                    "Nut Free","Diabetic","Vegetarian"],
  "index" : 2
  },
  {
  "title" : "Allergies",
  "subcategories" : ["Tree Nuts","Pitted Fruits","Gluten","Milk","Eggs","Peanuts","Fish","Shellfish"],
  "index" : 3
},
  {
  "title" : "Cuisine",
  "subcategories" : ["American","Italian","Chinese","Japanese",
                    "Vietnamese","Mediterranean","French","Mexican","Cantonese","Thai","Greek","Korean","German",
                    "Spanish","Hawaiian","Malaysian","Middle Eastern","Latin American","Irish","Indian","Filipino","Jamaican"],
  "index" : 4
  }
];
module.exports = filterData;
