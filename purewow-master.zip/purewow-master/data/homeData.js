var homeData = [
  {
    "key": "1",
		"imageUrl": "https://www.savingdessert.com/wp-content/uploads/2017/01/Buffalo-Chicken-Roll-Ups-1-800x533.jpg",
    "categoryTitles": "Appetizers",
  },
  {
    "key": "2",
		"imageUrl": "https://245xq72m7u8l39tsbf33v0j6-wpengine.netdna-ssl.com/wp-content/uploads/2015/06/Bissell-Breakfast-V2.jpg",
    "categoryTitles": "Breakfast",
  },
  {
    "key": "3",
    "imageUrl": "https://media0ch-a.akamaihd.net/31/16/b875c1b3acf51330b6909548c6ae12f9.jpg",
    "categoryTitles": "Lunches",
  },
  {
    "key": "4",
    "imageUrl": "https://tmbidigitalassetsazure.blob.core.windows.net/secure/RMS/attachments/37/1200x1200/Six-Layer-Dinner_exps6019_W101973175B07_06_3bC_RMS.jpg",
    "categoryTitles": "Dinners",
  },
  {
    "key": "5",
    "imageUrl": "https://food.fnr.sndimg.com/content/dam/images/food/fullset/2013/11/25/0/FNK_pan-seared-salmon-with-kale-apple-salad_s4x3.jpg.rend.hgtvcom.616.462.suffix/1387918756116.jpeg",
    "categoryTitles": "Main Dishes",
  },
  {
    "key": "6",
    "imageUrl": "https://www.seriouseats.com/recipes/images/20100901_cornsalad.jpg",
    "categoryTitles": "Side Dishes",
  },
  {
    "key": "7",
    "imageUrl": "https://hips.hearstapps.com/del.h-cdn.co/assets/16/21/1464036871-delish-summer-salads-chicken-fajita.jpg",
    "categoryTitles": "Salads",
  },
  {
    "key": "8",
    "imageUrl": "https://assets.epicurious.com/photos/57c5c317d8f441e50948d29f/2:1/w_1260%2Ch_630/foolproof-grilled-chicken.jpg",
    "categoryTitles": "Grilling",
  },
  {
    "key": "9",
    "imageUrl": "https://purewows3.imgix.net/images/articles/2016_12/sous_vide_wings.jpg?auto=format,compress&cs=strip",
    "categoryTitles": "Sous Vide",
  },
  {
    "key": "10",
    "imageUrl": "https://www.wellplated.com/wp-content/uploads/2017/03/Slow-Cooker-Mexican-Casserole-Chicken.jpg",
    "categoryTitles": "Crock Pot",
  },
  {
    "key": "11",
    "imageUrl": "https://www.aquicalmex.com/wp-content/uploads/2015/02/Sauses-dressings-salsas_EW_IMG_0298.jpg",
    "categoryTitles": "Sauces",
  },
  {
    "key": "12",
    "imageUrl": "https://www.ndtv.com/cooks/images/chicken.sweet.corn.soup.jpg",
    "categoryTitles": "Soups & Stews",
  },
  {
    "key": "13",
    "imageUrl": "https://cdn-image.myrecipes.com/sites/default/files/styles/medium_2x/public/image/recipes/sl/11/02/shoo-fly-punch-sl-x.jpg?itok=eg2anv2B",
    "categoryTitles": "Drinks",
  },
  {
    "key": "14",
    "imageUrl": "https://www.elementstark.com/woocommerce-extension-demos/wp-content/uploads/sites/2/2016/12/pizza.jpg",
    "categoryTitles": "Others",
  },
  {
    "key": "15",
		"imageUrl": "https://universityhealthnews.com/wp-content/uploads/healthy-thanksgiving-e1479860395137.jpg",
    "categoryTitles": "All Recipes",
  },
];
module.exports = homeData;
