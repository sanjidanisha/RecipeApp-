var dummyData =[
  {
    'name':'Erik'
  },
  {
    'name':'Emma'
  }
];

module.exports = dummyData;
