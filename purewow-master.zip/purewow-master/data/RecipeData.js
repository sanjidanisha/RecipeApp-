var RecipeData = [
	{
		"key": "1",
		"recipeTitle": "Blueberry Muffins",
		"imageUrl": "https://placekitten.com/150/150",
		"recipeAuthor": "Grace Kim",
		"categoryTitles": "Lunch",
		"recipeDesc": "This pot pie recipe is great for those seeking comfort food. Whether it's a cold you're fighting or the weather warm up with this amazing recipe.",
		"Ingredients": ["ice cream", "tomato"],
    "Time": "10 mins",
    "Directions": ["do this", "then this", "then this"],
    "Nutritional": "Calories: 253"

	},
	{
		"key": "2",
		"recipeTitle": "Peach Cobbler",
		"imageUrl": "https://placekitten.com/150/150",
		"recipeAuthor": "May Weather",
		"categoryTitles": "Lunch",
    "recipeDesc": "This pot pie recipe is great for those seeking comfort food. Whether it's a cold you're fighting or the weather warm up with this amazing recipe.",
		"Ingredients": ["ice cream", "tomato"],
    "Time": "10 mins",
    "Directions": ["do this", "then this", "then this"],
    "Nutritional": "Calories: 253"
	},
	{
		"key": "3",
		"recipeTitle": "Chicken Pot Pie",
		"imageUrl": "https://placekitten.com/150/150",
		"recipeAuthor": "Sarah Silky",
		"categoryTitles": "Appetizers",
    "recipeDesc": "This pot pie recipe is great for those seeking comfort food. Whether it's a cold you're fighting or the weather warm up with this amazing recipe.",
		"Ingredients": ["ice cream", "tomato"],
    "Time": "10 mins",
    "Directions": ["do this", "then this", "then this"],
    "Nutritional": "Calories: 253"
	},
	{
		"key": "4",
		"recipeTitle": "Steak Frites",
		"imageUrl": "https://placekitten.com/100/100",
		"recipeAuthor": "John Morlet",
		"categoryTitles": "Appetizers",
    "recipeDesc": "This pot pie recipe is great for those seeking comfort food. Whether it's a cold you're fighting or the weather warm up with this amazing recipe.",
		"Ingredients": ["ice cream", "tomato"],
    "Time": "10 mins",
    "Directions": ["do this", "then this", "then this"],
    "Nutritional": "Calories: 253"
	},
	{
		"key": "5",
		"recipeTitle": "Spinach Quiche",
		"imageUrl": "https://placekitten.com/150/150",
		"recipeAuthor": "Riley Deons",
		"categoryTitles": "Appetizers",
    "recipeDesc": "This pot pie recipe is great for those seeking comfort food. Whether it's a cold you're fighting or the weather warm up with this amazing recipe.",
		"Ingredients": ["ice cream", "tomato"],
    "Time": "10 mins",
    "Directions": ["do this", "then this", "then this"],
    "Nutritional": "Calories: 253"
	},
	{
		"key": "6",
		"recipeTitle": "5 Grilled Cheese",
		"imageUrl": "https://placekitten.com/100/100",
		"recipeAuthor": "Paula Ford",
		"categoryTitles": "Appetizers",
    "recipeDesc": "This pot pie recipe is great for those seeking comfort food. Whether it's a cold you're fighting or the weather warm up with this amazing recipe.",
		"Ingredients": ["ice cream", "tomato"],
    "Time": "10 mins",
    "Directions": ["do this", "then this", "then this"],
    "Nutritional": "Calories: 253"
	},
	{
		"key": "7",
		"recipeTitle": "5 hour Rib Eye",
		"imageUrl": "https://placekitten.com/150/150",
		"recipeAuthor": "Parker Madison",
		"categoryTitles": "Breakfast",
    "recipeDesc": "This pot pie recipe is great for those seeking comfort food. Whether it's a cold you're fighting or the weather warm up with this amazing recipe.",
		"Ingredients": ["ice cream", "tomato"],
    "Time": "10 mins",
    "Directions": ["do this", "then this", "then this"],
    "Nutritional": "Calories: 253"
	},
	{
		"key": "8",
		"recipeTitle": "Jerk Chicken",
		"imageUrl": "https://placekitten.com/150/150",
		"recipeAuthor": "Andrew Warner",
		"categoryTitles": "Breakfast",
    "recipeDesc": "This pot pie recipe is great for those seeking comfort food. Whether it's a cold you're fighting or the weather warm up with this amazing recipe.",
		"Ingredients": ["ice cream", "tomato"],
    "Time": "10 mins",
    "Directions": ["do this", "then this", "then this"],
    "Nutritional": "Calories: 253"
	},
];

module.exports = flatListData;
