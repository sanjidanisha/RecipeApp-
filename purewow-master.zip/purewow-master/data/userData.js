var userData =[
  {
    'name':'Erik Villavera',
    'email':'erik@gmail.com',
    'password':'Friedchicken'
  },
  {
    'name':'Emma Fujita',
    'email':'Emma@gmail.com',
    'password':'theGodfather'
  },
  {
    'name':'Debugger',
    'email':'Debug',
    'password':''
  },
  {
    'name':'Amaryce Osorio',
    'email':'Amaryce@gmail.com',
    'password':'developer'
  },
  {
    'name':'Sanjida Nisha',
    'email':'Sanjida@gmail.com',
    'password':'uxdesigner'
  },
  {
    'name':'Grace Kim',
    'email':'Grace@gmail.com',
    'password':'teamcoordinator'
  }
];

module.exports = userData;
