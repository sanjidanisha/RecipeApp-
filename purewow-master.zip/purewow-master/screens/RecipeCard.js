import React, { Component } from 'react';
import {ScrollView, Clipboard,ToastAndroid, AlertIOS, ImageBackground, Platform, CameraRoll, Linking, ListView, BackHandler, StyleSheet, Button, TouchableWithoutFeedback, AppRegistry, FlatList, Text, View, AsyncStorage, Image, Alert, Share, TouchableHighlight, TouchableOpacity, TextInput,} from 'react-native';
import StarRating from 'react-native-star-rating';
import FooterTabIcon from '../components/FooterTabIcon';
import { Drawer, Icon, Container, Header, Content, Left, Body, Right } from 'native-base';
import { List, ListItem, CheckBox, SocialIcon, Overlay } from 'react-native-elements';
import flatListData from '../data/flatListData';
import favoriteListData from '../data/favoriteListData';
import flatListData2 from '../data/flatListData2';
import RNInstagramShare from 'react-native-instagram-share';
import HTMLView from 'react-native-htmlview';
import FBSDK, {LoginButton, ShareDialog, AccessToken, LoginManager} from 'react-native-fbsdk';
import ReactNativeAN from 'react-native-alarm-notification';
import { shareOnFacebook, shareOnTwitter,} from 'react-native-social-share';
import  RNInstagramOAuth from 'react-native-instagram-oauth';
import { Rating, AirbnbRating } from 'react-native-ratings';
import Btn from 'react-native-micro-animated-button';
// import { ImagePicker } from 'react-native-sdk-28.0.0';
import Dialog from "react-native-dialog";
import DateTimePicker from 'react-native-modal-datetime-picker';
import Modal from "react-native-modal";

var image = 'assets-library://asset/asset.JPG?id=C4E468CC-3B82-4822-8FEE-BA1C1DC47B4B&ext=JPG';
var video = 'assets-library://asset/asset.mov?id=4D8172B1-EE3A-43D7-97BF-951003BFE97A&ext=mov';
var caption = "Test Message";

// const FBSDK = require('react-native-fbsdk');
export default class RecipeCard extends Component {
  constructor (props) {
    super(props);
    this.relatedRecipes = this.relatedRecipes.bind(this);
    this.filterProtein = this.filterProtein.bind(this);
    this.filterCuisine = this.filterCuisine.bind(this);
    this.bestMatchAll = this.bestMatchAll.bind(this);
    this.bestMatchNotAll = this.bestMatchNotAll.bind(this);
    this.setAll = this.setAll.bind(this);
    this.state = {

      starCount: 0,
      ratingss: 0,
      votes: 1,
      totalNum: 1,
      data: 0,
      relatedRecipes: [],
      type: 'Ionicons',
      checked: false,
      ratess: 0,
      ratings: 0,
      rating1: 0,
      heart: false,
      title: flatListData2[2].recipeTitle,
      modalVisible: false,
      currID: '',
      recipe: '',
    };
    const shareLinkContent = {
      contentType: 'link',
      contentUrl: 'https://www.facebook.com/',
      contentDescription: 'Facebook sharing is easy!'
    };

    this.state = {shareLinkContent: shareLinkContent,};
  }
  onButtonPressed() {

Contacts.getAll((err, contacts) => {
if (err) throw err;

// contacts returned
console.log(contacts)
});
      }
  shareLinkWithShareDialog() {
    var tmp = this;
    ShareDialog.canShow(this.state.shareLinkContent).then(
      function(canShow) {
        if (canShow) {
          return ShareDialog.show(tmp.state.shareLinkContent);
        }
      }
    ).then(
      function(result) {
        if (result.isCancelled) {
          alert('Share cancelled');
        } else {
          alert('Share success with postId: ' + result.postId);
        }
      },
      function(error) {
        alert('Share fail with error: ' + error);
      }
    );
  }
  relatedRecipes(){
    let protein = this.props.navigation.getParam('item').protein
    let type = this.props.navigation.getParam('item').cuisine

    if(this.props.navigation.getParam('isAll')){
      let arr1,arr2
      let arr = []

      arr1 = this.filterProtein(this.props.navigation.getParam('categoryArr'),this.props.navigation.getParam('item').protein)
      arr2 = this.filterCuisine(this.props.navigation.getParam('categoryArr'),this.props.navigation.getParam('item').cuisine)
      //the arrays contain the items right now
      arr = arr.concat(arr1,arr2)

      arr = this.bestMatchAll(arr,this.props.navigation.getParam('categoryArr'))

      for(var i = 0; i < arr.length; i++){
        if(arr[i] == this.props.navigation.getParam('item').key){
          arr.splice(i,i+1)
        }
      }
      if(arr.length > 3){
        arr.splice(3,arr.length)
      }
      for(var i = arr.length-1; i > -1; i--){
          if(arr[i] == -1){
            arr.splice(i, i+1)
          }
      }
      //temporary fix this code adds a random recipe for when there arent any or not 3 related recipes
      while(arr.length < 3){
        arr.push(6)
      }
      //arr contains the IDs of which objects to be displayed
      //not perfected
      this.setState({relatedRecipes: arr})
    }else{
      let arr1,arr2
      let arr = []

      arr1 = this.filterProtein(this.props.navigation.getParam('categoryArr'),this.props.navigation.getParam('item').protein)

      arr2 = this.filterCuisine(this.props.navigation.getParam('categoryArr'),this.props.navigation.getParam('item').cuisine)
      //the arrays contain the items right now

      arr = arr.concat(arr1,arr2)

      arr = this.bestMatchNotAll(arr,this.props.navigation.getParam('categoryArr'))

      for(var i = 0; i < arr.length; i++){
        if(arr[i] == this.props.navigation.getParam('item').key){
          arr.splice(i,i+1)
        }
      }
      if(arr.length > 3){
        arr.splice(3,arr.length)
      }
      for(var i = arr.length-1; i > -1; i--){
          if(arr[i] == -1){
            arr.splice(i, i+1)
          }
      }
      //temporary fix this code adds a random recipe for when there arent any or not 3 related recipes
      while(arr.length < 3){
        arr.push(6)
      }
      //arr contains the IDs of which objects to be displayed
      //not perfected
      this.setState({relatedRecipes: arr})
    }
  }
  filterProtein(category,protein){
  	let arr = [];
  	 category.map((foodData) => {
  	  if(foodData.protein.toLowerCase() === protein.toLowerCase()){
  		arr.push(foodData)
  	}
  	})
  	return arr
  }
  filterCuisine(category,cuisine){
  	let arr = [];
  	category.map((foodData) => {
  	if(foodData.cuisine.toLowerCase() === cuisine.toLowerCase()){
  		arr.push(foodData)
  	}
  	})
  	return arr
  }
  bestMatchAll(arr,categoryArr){
  	let arrReturn = []
  	let arrCounter = new Array(categoryArr.length)
  	this.setAll(arrCounter, 0)
  	arr.map((food) => {
  		arrCounter[food.id]++
  	})
    // Alert.alert('Food Counter: ' + arrCounter)
  	// console.log("Food Match Arr: " + arrCounter)
  	//arrcounter now has the most matched items and they are marked by the index
  	//for example arrCounter[1] represents food ID 1
  	while(arrReturn.length != arrCounter.length){
  		let max = 0;
  		let pos = -1;
  		for(var i = 0; i < arrCounter.length; i++){
  			if(arrCounter[i] > max && arrReturn.indexOf(i) == -1){
  				max = arrCounter[i]
  				//error here
  				pos = i
  			}
  		}
  		arrReturn.push(pos)
  		delete arrCounter[pos]
  	}
  	// console.log("Food ID to be displayed: " + arrReturn)
  	return arrReturn
  }
  bestMatchNotAll(arr,categoryArr){
  	let arrReturn = []
  	let arrCounter = new Array(categoryArr.length)
  	this.setAll(arrCounter, 0)
  	arr.map((food) => {
  		arrCounter[food.key]++
  	})
    // Alert.alert('Food Counter: ' + arrCounter)
  	// console.log("Food Match Arr: " + arrCounter)
  	//arrcounter now has the most matched items and they are marked by the index
  	//for example arrCounter[1] represents food ID 1
  	while(arrReturn.length != arrCounter.length){
  		let max = 0;
  		let pos = -1;
  		for(var i = 0; i < arrCounter.length; i++){
  			if(arrCounter[i] > max && arrReturn.indexOf(i) == -1){
  				max = arrCounter[i]
  				//error here
  				pos = i
  			}
  		}
  		arrReturn.push(pos)
  		delete arrCounter[pos]
  	}
  	// console.log("Food ID to be displayed: " + arrReturn)
  	return arrReturn
  }
  setAll(a, v) {
      var i, n = a.length;
      for (i = 0; i < n; i++) {
          a[i] = v;
      }
  }
  componentWillMount(){
    this.relatedRecipes()
    let liked = false;
    let arr;
    AsyncStorage.getItem('Favorites',(err,favorites) => {
      arr = JSON.parse(favorites)[this.props.navigation.getParam('currID') - 1]
      for(var i = 0; i < arr.length;i++){
        if(arr[i] == this.props.navigation.getParam('item').id){
          liked = true
        }
      }
      this.setState({currID: this.props.navigation.getParam('currID'),
      recipe: this.props.navigation.getParam('item'), heart: liked})
    })
  }
  render(){
const { navigation } = this.props;
return(
  <Container>
    <Header>
      <Left>
      <Icon name="ios-arrow-back"
          title="f"
          color='black'
          onPress={() => navigation.navigate(navigation.getParam('navigateBack'))}
      />
      </Left>
      <Body>

          <Image style={{width: 120, height: 42}} source={require('../images/PureWow_logo.png')} />
      </Body>
      <Right>
         <Text />
      </Right>
    </Header>
    <View style={styles.container}>
      <ScrollView>
          <View style={styles.overlay}>
          <Text style={styles.textos}> </Text>
          <NameAuthor navigation={navigation}/>
          <PrepTime navigation={navigation}/>
          <View style={{
            flex: 1,
            flexDirection: 'column',
            justifyContent: 'center',
            alignItems: 'center',
            }}
            >
            <Image
              source={{uri:this.props.navigation.getParam('item').imageUrl}}
              style={{
              width: 400,
              height: 250,
              }}>
            </Image>
            {
              this.state.heart ? <Icon name="heart" style={{color:'#ee4f4f', flexDirection:'row', position: 'absolute', paddingLeft:320, paddingTop: 130}} onPress={this.onResetLike} type="FontAwesome" color='red'/> :
              <Icon name="heart" type="Ionicons" style={{color:'#ee4f4f', flexDirection:'row', position: 'absolute', paddingLeft:320, paddingTop: 130}} onPress={this.onLike} />
            }
            <Text style={styles.desc}>{this.props.navigation.getParam('item').recipeIntro}</Text>
          </View>
          <Ingredient />
          <Directions />
          <View style={{
            flex: 1,
            flexDirection: 'column',
            justifyContent: 'center',
            alignItems: 'center',
            marginTop: 20
          }}>
            <View style={{flex: 1, flexDirection: 'row', justifyContent:'center', alignItems:'center'}}>
              <View style={{flex: 1, justifyContent: 'center', alignItems:'flex-end', marginLeft: 15}}>
                <Text style={{textAlign:"center", fontFamily: "Arial", fontSize: 16}}>Share:</Text>
              </View>
              <SocialIcon type='facebook' onPress={this.shareLinkWithShareDialog.bind(this)} raised={true} style={{width:40, height: 40, margin: 5, justifyContent: 'center', alignItems: 'center', borderRadius: 10}}/>
              <SocialIcon type='instagram' onPress={this._shareTextWithTitle} raised={true} style={{width:40, height: 40, margin: 5, justifyContent: 'center', alignItems: 'center', borderRadius: 10}}/>
              <SocialIcon type='pinterest' onPress={this._shareTextWithTitle} raised={true} style={{width:40, height: 40, margin: 5, marginRight: 10, justifyContent: 'center', alignItems: 'center', borderRadius: 10}}/>
            </View>
            <View style={{flex: 1,flexDirection: 'row'}}>
              <Text style={styles.rates}>Rate this Recipe:                Average: </Text>
              </View>
            <View style={{flex: 1, flexDirection: 'column', justifyContent: 'center', alignItems: 'center'}}>

              <View style={{flex: 1,flexDirection: 'row'}}>
              <StarRating disabled={false} fullStarColor={"#f27676"} emptyStarColor={'#ee4f4f'} maxStars={5} starSize={30} rating={this.state.starCount} selectedStar={rating => this.onStarRatingPress(rating)}/>
              <Text>          </Text>
              {<StarRating disabled={true} fullStarColor={"#f27676"} emptyStarColor={'#ee4f4f'} maxStars={5} starSize={30} rating={this.state.ratingss} /> }
              </View>
            </View>
            {/* <TouchableOpacity style={styles.ratess} ><Text style={styles.submit}>Submit</Text></TouchableOpacity> */}
          </View>
        </View>
      <Nutrition/>
      <Flexboxes navigation={navigation} relatedRecipes={this.state.relatedRecipes}/>
      </ScrollView>
    </View>
    <FooterTabIcon navigation={navigation}/>
   </Container>
)}

facebookShare (){
   shareOnFacebook({
       'text':'Global democratized marketplace for art',
       'link':'https://artboost.com/',
       'imagelink':'https://artboost.com/apple-touch-icon-144x144.png',
       //or use image
       'image': 'artboost-icon',
     },
     (results) => {
       console.log(results);
     }
   );
 }
 onStarRatingPress(rating) {
   this.setState({
     starCount: rating,
     ratingss: (this.state.starCount + rating) / 2


   });
   // this.setState(previousState => {
   //   return {
   //     // totalNum: previousState.totalNum + this.state.starCount,
   //     votes: previousState.votes + 1,
   //
   //   };
   // });
   // this.state.votes = this.state.votes + this.state.starCount;



   // values.push(this.state.starCount);
   // values = values.reduce((previous, current) => current += previous);
   // values /= count;
   // count = values;
   // AsyncSorage.setItem('rate', JSON.stringify(this.state.ratingss));
 }
 displayData = async () => {
   try {
     // let rate = await AsyncStorage.getItem('rate');
     // let ratings1 = parseInt(rate);
     this.setState({
       // ratings1 : parseInt(rate, 10)
       ratingss: parseInt(JSON.parse(await AsyncStorage.getItem('rate')))
     });
     console.log(ratingss);
     // alert(this.state.newCount);
   } catch (error) {
     alert(error);
   }
 };
  onResetLike = () =>{
    this.setState({heart:false})
    AsyncStorage.getItem('Favorites',(err,favorites) => {
      let orgFavorites = JSON.parse(favorites)
      let order = JSON.parse(favorites)[this.state.currID - 1]
      for(var i = 0; i < order.length; i++){
        if(order[i] == this.state.recipe.id){
          order.splice(i,1)
        }
      }
      orgFavorites[this.state.currID-1] = order
      AsyncStorage.setItem('Favorites',JSON.stringify(orgFavorites))
    })
  }
  onLike = () =>{
    this.setState({heart:true})
    AsyncStorage.getItem('Favorites',(err,favorites) => {
      let orgFavorites = JSON.parse(favorites)
      let order = JSON.parse(favorites)[this.state.currID - 1]
      order.push(this.state.recipe.id)
      orgFavorites[this.state.currID-1] = order
      AsyncStorage.setItem('Favorites',JSON.stringify(orgFavorites))
    })
  }

 _shareTextWithTitle() {
   let pics =
   flatListData2[2].imageUrl;
   Share.share(
   {
   message: flatListData2[2].recipeIntro,
   //for message you can have recipe here. just make recipe = this.state.recipes so ya dont have to constantly retype it?
   title: flatListData2[2].recipeTitle,
   url: pics,
   },
   {
   dialogTitle: 'title?',

   tintColor: '#7FFFD4',
   }
   )
   .then(this._showResult)
   .catch(err => console.log(err));
   }
}

class Ingredient extends Component{
  constructor (props) {
    super (props);
    this.state = {
      empty: "",
      checked: false, checked1: false, checked2: false, checked3: false, checked4: false, checked5: false, checked6: false, checked7: false, checked8: false, checked9: false, checked10: false,
      modalVisible: false
    };
  }
  onClickCheckBox = () => {
    if(this.state.check === false){
      this.setState({
        checked: true
      });
    }
    if(this.state.check === true){
      this.setState({
        checked: false
      });
    }
  }
  render() {
    return (
      <View style={styles.container}>
        <Text style={styles.ingred}> Ingredients: </Text>
          <View style={{borderBottomColor: 'black', borderBottomWidth: 1, margin: 10}}/>
          <Text style={styles.statement}>Check Off the Ingredients You Have</Text>
           <View style={{flex: 1, flexDirection: 'row', justifyContent: 'space-between',}}>
            <View style={{
              flex: 1,
              flexDirection: 'column',
            }}>

              <FlatList
                data={[{key: '4 Tomatoes'},]}
                renderItem={({item}) =>{
                  return(
                    <CheckBox
                      checkedIcon='check-square'
                      title={item.key}
                      size={25}
                      checkedColor='#f27676'
                      containerStyle={{backgroundColor:'transparent', borderColor: 'transparent', margin: 0.00001, marginLeft: 0, marginRight: 0}}
                      checked={this.state.checked1}
                      onPress={() => this.setState({checked1: !this.state.checked1})}
                      fontFamily="Arial"
                      textStyle={{
                        fontSize: 15,
                        color: 'black',
                        fontWeight: 'normal' }}
                    />
                  );
                }} />
              <FlatList
                data={[{key: '1 Whole Chicken'},]}
                renderItem={({item}) =>{
                  return(
                    <CheckBox
                      checkedIcon='check-square'
                      title={item.key}
                      size={25}
                      checkedColor='#f27676'
                      onPress={() => this.setState({checked2: !this.state.checked2})}
                        containerStyle={{backgroundColor:'transparent', borderColor: 'transparent', margin: 0.00001, marginLeft: 0, marginRight: 0}}
                        checked={this.state.checked2}
                        fontFamily="Arial"
                        textStyle={{
                        fontSize: 15,
                        fontWeight: 'normal',
                        color: 'black'
                        }}
                      />
                    );
                    }}
                />
            </View>
            <View style={{
              flex: 1,
              flexDirection: 'column',
              // justifyContent: 'space-between',
              }}>
              {/* <View style={{ flexDirection: 'row' }}>
                <CheckBox
                size={25}
                checkedIcon='check-square'
                checkedColor='#f27676'
                containerStyle={{backgroundColor:'transparent', borderColor: 'transparent', margin: 0.00001, marginLeft: 30}}
                checked={this.state.checked}
                onPress={() => this.setState({checked: true})}
                onPress={() => this.setState({checked1: true,checked2: true, checked3: true, checked4: true})}
                />
                <Text style={{marginTop:10}}> Select all</Text>
              </View>
              <View style={{ flexDirection: 'row' }}>
                <CheckBox
                  checkedIcon='check-square'
                size={25}
                checkedColor='#f27676'
                containerStyle={{backgroundColor:'transparent',   borderColor: 'transparent', margin: 0.00001, marginLeft: 1}}
                checked={this.state.checked}
                checked1= {this.state.checked1}
                checked2= {this.state.checked2}
                checked4={this.state.checked4}
                checked4= {this.state.checked4}
                onPress={() => this.setState({checked1: false,checked2: false, checked3: false, checked4: false})}
                />
                <Text style={{marginTop:10}}> Clear all</Text>
                </View> */}

              <FlatList
                data={[{key: '1 Sprig of Parsley'},]}
                renderItem={({item}) =>{
                  return(
                    <CheckBox
                      checkedIcon='check-square'
                      title={item.key}
                      size={25}
                      checkedColor='#f27676'
                        onPress={() => this.setState({checked3: !this.state.checked3})}
                      containerStyle={{backgroundColor:'transparent', borderColor: 'transparent', margin: 0.00001, marginLeft: 0, marginRight: 0}}
                      checked={this.state.checked3}
                      fontFamily="Arial"
                      textStyle={{
                        fontSize: 15,
                        fontWeight: 'normal',
                        color: 'black'
                      }}
                    />
                  );
                  }} />
            <FlatList
              data={[{key: '2 Egg Whites'},]}
               renderItem={({item}) =>{
               return(
                <CheckBox
                  checkedIcon='check-square'
                  title={item.key}
                  size={25}
                  checkedColor='#f27676'
                  containerStyle={{backgroundColor:'transparent', borderColor: 'transparent',margin: 0.00001, marginLeft: 0, marginRight: 0}}
                  checked={this.state.checked4}
                  fontFamily="Arial"
                  textStyle={{
                    fontSize: 15,
                    fontWeight: '300',
                    color: 'black'
                  }}
                  onPress={() => this.setState({checked4: !this.state.checked4})}
                />
              );
              }} />
              {/* <View style={{ flexDirection: 'row' }}>
                <CheckBox
                size ={30}
                checkedColor='#f27676'
                title={"Clear All"}
                containerStyle={{backgroundColor:'transparent',   borderColor: 'transparent', margin: 0.00001,}}
                checked={this.state.checked}
                checked1= {this.state.checked1}
                checked2= {this.state.checked2}
                checked4={this.state.checked4}
                checked4= {this.state.checked4}
                onPress={() => this.setState({checked1: false,checked2: false, checked3: false, checked4: false})}
                textStyle={{
                fontSize: 17,
                fontWeight: 'normal',
                color: 'black'
                }}
                />

                </View> */}
              </View>

            </View>
            <View style={{
              flex: 1,
              flexDirection: 'row',
              justifyContent: 'center',
            }}>
      <Modal
         animationType="slide"
         transparent={false}
         visible={this.state.modalVisible}
         onRequestClose={() => {
         alert('Modal has been closed.');
         }}
         style={styles.modal}
         >
         <View height={200}>
          <View flexDirection='row' justifyContent='space-between' >
            <Button title='Cancel' onPress={() => this.setState({modalVisible:false})}/>
            <Button title='Save' onPress={() => this.setState({modalVisible:false})}/>
          </View>
          <View alignItems='center'>
            <Text style={{marginTop: 20,marginBottom: 20, fontFamily: 'Arial', fontSize:15}}>Enter Your phone number </Text>
          </View>
          <View alignItems='center'>
            <TextInput placeholder='Phone Number'/>
            <TouchableOpacity disabled={true} style={styles.phonenumberinput} />
          </View>
          <View alignItems = 'center'>
           <Button title = 'Contacts'  />
           <TouchableOpacity disabled={true} style={styles.contacts} />
          </View>
          <View alignItems= 'center'>
            <Button title = 'Send Message' onPress={() => Alert.alert('Your ingredient list has been sent!') }/>
          </View>
        </View>
      </Modal>

          <TouchableOpacity
           style={styles.remind}
           onPress={() => this.setState({modalVisible: true})}
           >
            <Text style={{fontSize: 17, fontFamily: "Arial", color: 'white'}}>Text List</Text>
          </TouchableOpacity>
            <DateTimePickerTester/>
            </View>
          </View>
      );
  }
}

class Directions extends Component {
  constructor (props) {
    super (props);
    this.state = {
      checked: false, checked1: false, checked2: false, checked3: false, checked4: false, checked5: false, checked6: false, checked7: false, checked8: false, checked9: false, checked10: false
    };
  }
  render() {
    return(
      <View style = {styles.container}>
        <Text style={styles.ingred}>Directions: </Text>
        <View style={{borderBottomColor: 'black', borderBottomWidth: 1, margin:10}}/>
        <View style={{
          flex: 1,
          flexDirection: 'column',
        }}>
          <FlatList
            data={[{key: 'Preheat oven to 425 degrees F (220 degrees C).'}]}
            renderItem={({item}) =>{
              return(
              <CheckBox
                checkedIcon='check-square'
                title={item.key}
                size={25}
                checkedColor='#f27676'
                textStyle={{
                  fontSize: 15,
                  fontWeight: '300',
                  color: 'black',
                  fontFamily:"Arial"
                }}
                containerStyle={{backgroundColor:'transparent', borderColor: 'transparent', margin: 0.00001}}
                checked={this.state.checked2} onPress={() => this.setState({checked2: !this.state.checked2})}
              />
            );
          }} />
          <FlatList
            data={[{key: 'Slice tomatoes to desired thickness.'}]}
            renderItem={({item}) =>{
            return(
              <CheckBox
                checkedIcon='check-square'
                size={25}
                title={item.key}
                checkedColor='#f27676'
                textStyle={{
                  fontSize: 15,
                  fontWeight: '300',
                  color: 'black',
                  fontFamily:"Arial"
                }}
                containerStyle={{backgroundColor:'transparent', borderColor: 'transparent', margin: 0.00001}}
                checked={this.state.checked} onPress={() => this.setState({checked: !this.state.checked})}
                />
            );
          }}/>
        </View>
      </View>
    );
  }
}
// <FlatList
//   data={[{key: 'Arrange the halved tomatillos, Anaheim chiles, jalapenos, onion, and green bell pepper on a baking sheet. Drizzle the vegetables with 1 tablespoon of olive oil.'},]}
//   containerStyle={{backgroundColor:'transparent', borderColor: 'transparent', margin: 0.00001}}
//   checked={this.state.checked2} onPress={() => this.setState({checked2: !this.state.checked2})} />


class Flexboxes extends Component {
  constructor (props) {
    super (props);
    this.state = {

      imagedata: 1
    };
  }
  render () {
    dataChange = () =>{
      this.setState({
        imagedata:3
      });
    }

    return (
      <View>
        <Text style={styles.ingred}>Related Recipes: </Text>
        <View style={{borderBottomColor: 'black', borderBottomWidth: 1, margin: 10}}/>
        <View style={{flex: 1, flexDirection: 'row', justifyContent: 'space-between',}}>
          <TouchableOpacity style={{justifyContent: 'center', alignItems: 'center', marginBottom: 10}} onPress={this.dataChange}>
          <Image
              source={{uri:this.props.navigation.getParam('categoryArr')[this.props.relatedRecipes[0]].imageUrl}}
                  style={{
                   width: 105,
                   height: 105,
                   margin: 8
                  }}
          />
          <View width={100}>
            <Text style={styles.relatedtext}> {this.props.navigation.getParam('categoryArr')[this.props.relatedRecipes[0]].recipeTitle} </Text>
          </View>
          </TouchableOpacity>
        <TouchableOpacity style={{justifyContent: 'center', alignItems: 'center', marginBottom: 10}} onPress={() => this.props.navigation.navigate('Recipe')}>
        <Image
            source={{uri:this.props.navigation.getParam('categoryArr')[this.props.relatedRecipes[1]].imageUrl}}
            style={{
              width: 105,
              height: 105,
              margin: 8
            }}
            >
            </Image>
            <View width={100}>
              <Text style={styles.relatedtext}> {this.props.navigation.getParam('categoryArr')[this.props.relatedRecipes[1]].recipeTitle} </Text>
            </View>
            </TouchableOpacity>
          <TouchableOpacity style={{justifyContent: 'center', alignItems: 'center', marginBottom: 10}} onPress={() => this.props.navigation.navigate('Recipe')}>
          <Image
              source={{uri:this.props.navigation.getParam('categoryArr')[this.props.relatedRecipes[2]].imageUrl}}
              style={{
                width: 105,
                height: 105,
                margin: 8
              }}
              >
              </Image>
              <View width={100}>
                <Text style={styles.relatedtext}> {this.props.navigation.getParam('categoryArr')[this.props.relatedRecipes[2]].recipeTitle} </Text>
              </View>
              </TouchableOpacity>
        </View>
      </View>
      )
    }
  }

  class CardElement extends Component {

  	render() {
  		return (
          <View>
          //this.props.item.imageUrl
              <ImageBackground source={{uri: this.props.item.imageUrl}}
               style={styles.homeTile}>
              <Text style={styles.homeText}>{this.props.item.categoryTitles}</Text>
             </ImageBackground>
          </View>
      );
  	}
  }

class Nutrition extends Component{
  constructor (props) {
    super (props);
    this.state = {
      data: 2
    };
  }
  render(){

    return(
      <View>
      <Text style={styles.ingred}>Nutritional Facts: </Text>
      <View style={{borderBottomColor: 'black', borderBottomWidth: 1, margin: 10, }}/>
      <View style={styles.desc}>

      <Text style={{
        fontSize: 17,
        fontFamily: "Arial",
        marginLeft: 14,}}>Serving Size: 8</Text>
      <View style={{borderBottomColor: 'black', borderBottomWidth: 1, margin: 10}}/>
      <Text style={{
        fontSize: 17,
        fontFamily: "Arial",
        marginLeft: 14,}}>{flatListData2[this.state.data].NutritionalCalories}</Text>
      <View style={{borderBottomColor: 'black', borderBottomWidth: 1, margin: 10}}/>
      <Text style={{
        fontSize: 17,
        fontFamily: "Arial",
        marginLeft: 14,}}>{flatListData2[this.state.data].NutritionalFat} </Text>
      <View style={{borderBottomColor: 'black', borderBottomWidth: 1, margin: 10}}/>

      </View>
      </View>
    )
  }
}

class ImageDesc extends Component{
  constructor (props) {
    super(props);
    this.state = {
      heart: false,
    };
  }

  render(){
    return(
      <View style={{
        flex: 1,
        flexDirection: 'column',
        justifyContent: 'center',
        alignItems: 'center',
        }}
        >
        <Image
          source={{uri:this.props.navigation.getParam('item').imageUrl}}
          style={{
          width: 400,
          height: 250,
          }}>
        </Image>
        <Text style={styles.desc}>{this.props.navigation.getParam('item').recipeIntro}</Text>
      </View>
    )
  }
  onLikeButton= async () => {
     this.setState({heart:true})
     AsyncStorage.setItem('liket', JSON.stringify(flatListData2[2]));
     this.displayLike();
   }
   async componentDidMount(){
     this.onLikeButton = await this.onLikeButton.bind(this);
   }

   displayLike = async () => {
     try{
       favoriteListData.push(JSON.parse(await AsyncStorage.getItem('liket')));

     } catch (error) {
       alert(error);
     }
   }
   onResetLike =() =>{
     this.setState({heart:false})
     favoriteListData.splice("key", 2);
   }

}

class NameAuthor extends Component{
  render(){
    return(

        <View style={{
          flex: 1,
          flexDirection: 'column',
        }}>
      <TouchableOpacity disabled={true} style={styles.button}>
      <Text style={styles.button}> {this.props.navigation.getParam('item').recipeTitle}</Text>

      <Text style={styles.button1}>By: {this.props.navigation.getParam('item').recipeAuthor}</Text>
      </TouchableOpacity>
      <Text></Text>

  </View>
      )
    }
  }

class PrepTime extends Component {
  render(){
    return(
      <View style={{flex: 1, flexDirection: 'row', alignItems: 'center'}}>

        <Text style={styles.prep}>
        <Text style={styles.moretext}> Prep Time: {this.props.navigation.getParam('item').prepTime} mins  | Cook Time: {this.props.navigation.getParam('item').cookTime} mins | Total Time:  {this.props.navigation.getParam('item').totalTime} mins</Text></Text>

          <View style={{
            flex: 1,
            flexDirection: 'column',
          }}>
          <Text></Text>
          <Text></Text>
        </View>
      </View>
      )
    }
  }

const styles = StyleSheet.create({
    container: {
      flex: 1,
    },

    prep:{
      backgroundColor: "#f27676",
      paddingRight: 700,
      paddingLeft: 5,
      width: 500,
      height: 25,
      paddingTop: 5,
      color: 'white',
      alignItems: 'center',
      borderColor: "#f27676",
      flex: 1,
      justifyContent: 'space-between'
    },

    button:{
      textAlign : 'center',
      fontWeight: 'bold',
      fontSize: 25,
      fontFamily: "Arial",
      borderColor: 'black',
    },

    button1: {
      textAlign : 'center',
      fontSize: 18,
      fontFamily: "Arial",
      margin: 2,
    },

    texto: {
      color: '#000',
      fontSize: 18,
      textAlign: 'center',
      fontFamily: "Arial",
    },

    moretext: {
      color: 'white',
      fontSize: 12,
      justifyContent: 'center',
      textAlign: 'center',
      fontWeight: "bold",
      fontFamily: "Arial",
    },

    desc:{
      color: '#000',
      fontSize: 15,
      marginTop: 10,
      marginLeft: 10,
      marginRight: 10,
      fontFamily: "Arial",
      fontWeight: "400"
    },

    sharebutt:{
      textAlign: 'center',
      width: 60,
      padding: 15,
      height: 50,
      marginTop: 100,
      marginLeft:20,
    },

    sharebutts:{
      borderRadius: 5,
      width: '40%',
      justifyContent: 'space-between',
      alignItems: 'center',
      backgroundColor:"#f27676",
      padding: 10,
      marginTop: 10,
      margin: 10,
    },

    ingred:{
      fontSize: 16,
      fontFamily: "Arial",
      fontWeight: 'bold',
      marginLeft: 10,
      marginTop: 25,
    },

    relatedtext: {
      fontSize: 12,
      textAlign: 'center',
      justifyContent: 'center'
    },

    rates:{
      // textAlign:'center',
      fontSize: 15,
      marginRight: 67,
      // marginLeft: 100,
      fontFamily: "Arial",
      marginTop: 50,
      marginBottom: 5,
    },
    ratess:{
      textAlign:'center',
      fontSize: 15,
      marginRight: 5,
      // marginLeft: 100,
      fontFamily: "Arial",
      marginTop: 50,
      marginBottom: 5,
    },
    remind:{
      backgroundColor:"#f27676",
      borderRadius: 5,
      width: 165,
      height: 50,
      margin: 10,
      justifyContent: 'center',
      alignItems: 'center'
    },

    contacts: {
      marginTop: 10,
      marginBottom: 15,
    },

    modal:{
      margin:15
    },

    phonenumberinput:{
      marginTop:15,
    },

    statement:{
      marginBottom: 10,
      fontSize: 14,
      fontFamily: "Arial",
      fontWeight: '400',
      justifyContent: 'center',
      textAlign: 'center',
      marginLeft: 10,
    },

    submit:{
      fontFamily: "Arial",
      fontSize: 18,
      color: '#F06A6B',
      borderColor: '#F06A6B',
      borderWidth: 2,
      borderRadius: 5,
      paddingLeft: 20,
      paddingRight: 20,
      paddingTop: 10,
      paddingBottom: 10
    },

    nutri:{
      fontSize: 10,
      fontFamily: "Arial",
    }
});

class DateTimePickerTester extends Component {
  state = {
    isDateTimePickerVisible: false,
  };

  _showDateTimePicker = () => this.setState({ isDateTimePickerVisible: true });

  _hideDateTimePicker = () => this.setState({ isDateTimePickerVisible: false });

  _handleDatePicked = (time) => {
    console.log('A date has been picked: ', time);
    this._hideDateTimePicker();
  };

  render () {
    return (
      <View style={{ flex: 1 }}>
        <TouchableOpacity
          style={styles.remind} onPress={this._showDateTimePicker}>
          <Text style={{ fontSize: 17, fontFamily: "Arial", color: 'white'}}> Remind Me Later </Text>
        </TouchableOpacity>
        <DateTimePicker mode = {'time'}
          isVisible={this.state.isDateTimePickerVisible}
          onConfirm={this._handleDatePicked}
          onCancel={this._hideDateTimePicker}
        />
      </View>
    );
  }

}
