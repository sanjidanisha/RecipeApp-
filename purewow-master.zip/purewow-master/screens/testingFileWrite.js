import React, { Fragment, Component } from 'react';
import { AppRegistry,ScrollView, StyleSheet, FlatList, View, Image ,ImageBackground, Text } from 'react-native';
import dummyData from '../data/dummyData';

// var RNFS = require('react-native-fs');
// fs.writeFile("/tmp/test", "Hey there!", function(err) {
//     if(err) {
//         Alert.alert(err);
//     }
//
//     Alert.alert("The file was saved!");
// });
//
// export default class FileWrite extends Component {
//   render(){
//     return(
//       <View>
//         <Text> Testing </Text>
//       </View>
//     )
//   }
// }
