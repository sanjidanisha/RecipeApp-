import React, { Fragment, Component } from 'react';
import { AppRegistry, ScrollView, StyleSheet, FlatList, View, ImageBackground, Image, Text, Alert} from 'react-native';
import filterData from '../data/filterData';
import flatListData from '../data/flatListData';
import styles from '../styles/styles.js';
import * as ReactNativeElements from 'react-native-elements';
import Button from 'react-native-button';
import FooterTabIcon from '../components/FooterTabIcon';
import dummyData from '../data/dummyData';

// import Modal from 'react-overlays'
// import Sidebar from './Sidebar';
import { Drawer, Icon, Container, Header, Content, Left, Body, Right } from 'native-base';

const CheckboxesElement = ({dataArr,checkBoxArr,index,func}) => {
  const CheckBoxNode = dataArr.map((filter, iteration) =>{
    if(index == 0 )
    return(
      <ReactNativeElements.CheckBox left iconLeft checkedIcon='check-square' checkedColor='#f27676'
      uncheckedIcon='square-o' size={22} title={filter}
      checked={checkBoxArr[index][iteration]}
      onPress={() => func(index,iteration)} key={index + iteration} textStyle={{fontFamily:'Arial', fontSize: 14}} />
    )
    else return(
      <ReactNativeElements.CheckBox left iconLeft checkedIcon='check-square' checkedColor='#f27676'
      uncheckedIcon='square-o' size={22} title={filter}
      checked={checkBoxArr[index][iteration]}
      onPress={() => func(index,iteration)} key={index + iteration}
      containerStyle={{width:'47%', height: 'auto', marginLeft: 5, marginRight: 0}} textStyle={{fontFamily:'Arial', fontSize: 14}}  />
    )
  })
  return(
    CheckBoxNode
  )
}
const RecipeTiles = ({sortArray, categoryArr, navigation,isAll}) => {
  const tiles = sortArray.map((id,iteration) => {
    if(iteration%2 == 0)
    return(
      <ImageBackground key = {id} backgroundColor='#ddd' style={styles.recipeBackgroundOverlay} >
        <Tile key = {id} item={categoryArr[id]} categoryArr={categoryArr}
        sortArray={sortArray} navigation={navigation} isAll={isAll} />
      </ImageBackground>
    );
    return(
      <ImageBackground key = {id} backgroundColor='#fff' style={styles.recipeBackgroundOverlay} >
        <Tile key = {id} item={categoryArr[id]} categoryArr={categoryArr}
        sortArray={sortArray} navigation={navigation} isAll={isAll} />
      </ImageBackground>
    )
  })
  return(
    tiles
  )
}
const Tile = ({item,navigation,sortArray,categoryArr,isAll}) =>{
  return(
    <Button height={130} onPress={() => navigation.navigate('Card',{navigateBack: 'Filter',
    item: item, categoryArr: categoryArr, isAll: isAll, currID:navigation.getParam('currID') })}>
      <View>
        <ImageBackground source={{uri: item.imageUrl}}
         style={styles.allTile}/>
      </View>
      <View>
        <ImageBackground style={styles.textTile}>
          <Text style={styles.recipeTitleText}>{item.recipeTitle}{'\n'}</Text>
          <Text style={styles.recipeDescText}>Prep Time: {item.prepTime} mins</Text>
          <Text style={styles.recipeDescText}>Cook Time: {item.cookTime} mins</Text>
          <Text style={styles.recipeDescText}>Total Time: {item.totalTime} mins</Text>
        </ImageBackground>
      </View>
    </Button>
  )
}

export default class HomeScreen extends Component {
  constructor(props){
    super(props);
    this.checkBoxClick = this.checkBoxClick.bind(this);
    this.getCol = this.getCol.bind(this);
    this.grabTrue = this.grabTrue.bind(this);
    this.filterRecipes = this.filterRecipes.bind(this);
    this.filterTime = this.filterTime.bind(this);
    this.filterProtein = this.filterProtein.bind(this);
    this.filterType = this.filterType.bind(this);
    this.filterAllergy = this.filterAllergy.bind(this);
    this.filterCuisine = this.filterCuisine.bind(this);
    this.bestMatch = this.bestMatch.bind(this);
    this.setAll = this.setAll.bind(this);
    this.removeExtras = this.removeExtras.bind(this);
    this.grabCategory = this.grabCategory.bind(this);
    this.state = {
      checkBox: [Array(4).fill(false), Array(7).fill(false), Array(9).fill(false),
         Array(8).fill(false), Array(22).fill(false)],
      sortArray: this.props.navigation.getParam('sortArr'),
      overlayVisible: false,
      status: [true,false,false,false,false],
      categoryArr: this.props.navigation.getParam('categoryArr'),
      isAll: this.props.navigation.getParam('isAll')
      // sauce: this.props.navigation.getParam('sauce'),
      // soup: this.props.navigation.getParam('soup'),
    }
    this.initial = {
       sortArray: this.state.sortArray
    }
  }
  testing(id){
    Alert.alert('CurrID: ' + id)
  }
  grabCategory(){
    Alert.alert(this.state.categoryArr)
  }
  checkBoxClick(ind1,ind2){
    for(var row = 0; row < this.state.checkBox.length; row++){
      for(var col = 0; col < this.state.checkBox[4].length; col++){
        if(ind1 == row && ind2 == col){
          let oldArr = this.state.checkBox;
          oldArr[row][col] = !this.state.checkBox[row][col]
          this.setState({checkBox: oldArr})
          // Alert.alert(this.state.checkBox.toString())
        }
      }
    }
  }
  getCol(matrix, col){
    var column = [];
       for(var i=0; i<matrix[col].length; i++){
          column.push(matrix[col][i]);
       }
    return column;
  }
  grabTrue(arr){
    let arrReturn = []
    for(var i = 0; i < arr.length; i++){
      if(arr[i]){
        arrReturn.push(i)
      }
    }
    return arrReturn
  }
  filterRecipes(category){
    let numCategoryFilters = 0

    let timePos = this.grabTrue(this.getCol(this.state.checkBox,0))
    let proteinPos = this.grabTrue(this.getCol(this.state.checkBox,1))
    let allergiesPos = this.grabTrue(this.getCol(this.state.checkBox,2))
    let typePos = this.grabTrue(this.getCol(this.state.checkBox,3))
    let cuisinePos = this.grabTrue(this.getCol(this.state.checkBox,4))

    let arr1, arr2, arr3, arr4, arr5
    let arr = []

    timePos.length > 0 ? numCategoryFilters++ : null
    proteinPos.length > 0 ? numCategoryFilters++ : null
    allergiesPos.length > 0 ? numCategoryFilters++ : null
    typePos.length > 0 ? numCategoryFilters++ : null
    cuisinePos.length > 0 ? numCategoryFilters++ : null

    while(timePos.length > 0 || proteinPos.length > 0 || allergiesPos.length > 0 ||
    typePos.length > 0 || cuisinePos.length > 0){
      if(timePos.length == 0){
        arr1 = []
      }else{
        let time = filterData[0].times[timePos.pop()]
        arr1 = this.filterTime(this.state.categoryArr,time)
        // Alert.alert('Time Array: ' + arr1 + ' ' + timePos.pop().toString())
      }

      if(proteinPos.length == 0){
        arr2 = []
      }else{
        let protein = filterData[1].subcategories[proteinPos.pop()]
        arr2 = this.filterProtein(this.state.categoryArr,protein)
      }

      if(allergiesPos.length == 0){
        arr3 = []
      }else{
        let allergies = filterData[2].subcategories[allergiesPos.pop()]
        arr3 = this.filterAllergy(this.state.categoryArr,allergies)
      }

      if(typePos.length == 0){
        arr4 = []
      }else{
        let type = filterData[3].subcategories[typePos.pop()]
        arr4 = this.filterType(this.state.categoryArr,type)
      }

      if(cuisinePos.length == 0){
        arr5 = []
      }else{
        let cuisine = filterData[4].subcategories[cuisinePos.pop()]
        arr5 = this.filterCuisine(this.state.categoryArr,cuisine)
      }

      // Alert.alert('time: ' + timePos + ' protein: ' + proteinPos + ' allergies: ' + allergiesPos +
      // ' type: ' + typePos + ' cuisinePos: ' + cuisinePos)

      //has an array of items
      arr = arr.concat(arr1,arr2,arr3,arr4,arr5)
    }
    // Alert.alert('Before Best Match' + arr)
    // Alert.alert('Length Before Best Match' + arr.length)

    let str = ""
    for(var i = 0; i < arr.length; i++){
      str += arr[i].recipeTitle + " ";
    }
    // Alert.alert("Recipes Display: " + str)


    arr = this.bestMatch(arr, numCategoryFilters)

    // Alert.alert('After Best Match' + arr)

    let arrReturn = []
    for(var i = 0; i < arr.length;i++){
      if(arr[i] > -1){
        arrReturn.push(arr[i])
      }
    }

    // Alert.alert('Adding One ' + arr)

    // arr = this.removeExtras(arr, category)

    // Alert.alert("Order displayed: " + arr)

    this.setState({sortArray: arrReturn})
  }
  removeExtras(arr, category){
    arrReturn = []
    if(category.toLowerCase() === "all"){
      return arr
    }
    for(var i = 0; i < arr.length; i++){
      if(flatListData[arr[i]].categoryTitles.toLowerCase() === category.toLowerCase()){
        arrReturn.push(arr[i])
      }
    }
    return arrReturn
  }
  bestMatch(arr, numCategoryFilters){
  	let arrReturn = []
  	let arrCounter = new Array(this.state.categoryArr.length)
  	this.setAll(arrCounter, 0)
  	arr.map((food) => {
  		arrCounter[food.key]++
  	})
  	// console.log("Food Match Arr: " + arrCounter)
  	//arrcounter now has the most matched items and they are marked by the index
  	//for example arrCounter[1] represents food ID 1
  	while(arrReturn.length != arrCounter.length){
  		let max = 0;
  		let pos = -1;
  		for(var i = 0; i < arrCounter.length; i++){
  			if(arrCounter[i] >= numCategoryFilters && arrReturn.indexOf(i) == -1){
  				max = arrCounter[i]
  				//error here
  				pos = i
  			}
  		}
  		arrReturn.push(pos)
  		delete arrCounter[pos]
  	}
  	// console.log("Food ID to be displayed: " + arrReturn)
  	return arrReturn
  }
  setAll(a, v) {
      var i, n = a.length;
      for (i = 0; i < n; i++) {
          a[i] = v;
      }
  }
  filterTime(category,time){
  	let arr = [];
  	category.map((foodData) => {
  	if(foodData.totalTime <= time){
  		arr.push(foodData)
  	}
  	})
  	// Alert.alert("Time Arr " + arr[0].recipeTitle + ' ' + arr[0].key + ' ' + arr[1].recipeTitle + ' ' + arr[1].key)
  	return arr
  }
  filterProtein(category,protein){
  	let arr = [];
  	category.map((foodData) => {
  	if(foodData.protein.toLowerCase() === protein.toLowerCase()){
  		arr.push(foodData)
  	}
  	})
  	return arr
  }
  filterAllergy(category,allergies){
  	let arr = [];
  	category.map((foodData) => {
  	if(foodData.allergies.toLowerCase() === allergies.toLowerCase()){
  		arr.push(foodData)
  	}
  	})
  	return arr
  }
  filterType(category,type){
  	let arr = [];
  	category.map((foodData) => {
  	if(foodData.type.toLowerCase() === type.toLowerCase()){
  		arr.push(foodData)
  	}
  	})
  	return arr
  }
  filterCuisine(category,cuisine){
  	let arr = [];
  	category.map((foodData) => {
  	if(foodData.cuisine.toLowerCase() === cuisine.toLowerCase()){
  		arr.push(foodData)
  	}
  	})
  	return arr
  }
  categoryToggle(num){
    let arr = this.state.status
    arr[num] = !this.state.status[num]
    this.setState({status: arr})
  }
	render(){
		const { navigation } = this.props;
    let currID = this.props.navigation.getParam('currID')
    const checkBoxes = filterData.map((filters, iteration) => {
      return(
        <View key={iteration}>
          <Button onPress={() => this.categoryToggle(iteration)}>
            <Text style={styles.categoryText}>{filters.title}</Text>
            {
              this.state.status[iteration] ?
                <ReactNativeElements.Icon name='keyboard-arrow-down' />  : <ReactNativeElements.Icon name='chevron-right' />
            }
          </Button>
          {
            (iteration == 1 || iteration == 4 || iteration == 2 || iteration == 3) && this.state.status[iteration] ?
              <View flexDirection='row' flexWrap='wrap'>
                <CheckboxesElement index={filters.index} dataArr={filters.subcategories}
                checkBoxArr={this.state.checkBox} func={this.checkBoxClick.bind(this)} />
              </View> :

            (iteration == 0) && this.state.status[iteration] ?
            <View>
              <CheckboxesElement index={filters.index} dataArr={filters.subcategories}
              checkBoxArr={this.state.checkBox} func={this.checkBoxClick.bind(this)} />
            </View> : null
          }
        <ReactNativeElements.Divider style={{ borderTop: 1, marginTop: 10, marginBottom: 10 }} />
        </View>
        )
    });
		return (
			<Container>
				<Header>
          <Left>
          </Left>
          <Body>
             <Image style={{width: 120, height: 42}} source={require('../images/PureWow_logo.png')} />
          </Body>
          <Right>
            <Button onPress = {() => this.setState({overlayVisible: true})} >
              <Text style = {{fontSize: 18, margin: 5}} > Filter </Text>
              <ReactNativeElements.Icon name='filter-list' />
            </Button>
          </Right>
				</Header>
        <View style = {{flex:1}}>
          <View alignItems='center' margin={5} >
                <Text style = {styles.titleText}>{navigation.getParam('categoryTitle').toUpperCase()}</Text>
          </View>
          <ReactNativeElements.Divider style={{ borderTop: 1, marginTop: 10, marginBottom: 10 }} />
          <ScrollView>
            <View flexDirection="row" flexWrap="wrap">
              <RecipeTiles sortArray={this.state.sortArray} categoryArr={this.state.categoryArr} navigation={this.props.navigation}
              isAll={this.state.isAll}/>
              {
                (this.state.sortArray.length == 0) ?
                <Text style={styles.notFoundText}> "Looks like nothing matched your search. Please try again."
                </Text> : null
              }
            </View>
            <Text fontSize={14} fontWeight='bold'> Total Results: {this.state.sortArray.length} </Text>
          </ScrollView>
        </View>
          <ReactNativeElements.Overlay
            isVisible={this.state.overlayVisible}
            windowBackgroundColor="rgba(0, 0, 0, .5)"
            overlayBackgroundColor="white"
            width= {360}
            height= {500}
            // overlayStyle={{alignItems: 'center'}}
            containerStyle={{alignItems: 'center'}}
          >
          <View alignItems='flex-end' margin={5}>
            <Button onPress = {() => this.setState({overlayVisible: false})} >
              <ReactNativeElements.Icon name='close' />
            </Button>
          </View>
          <ScrollView width={340}>
            <View width={330}>
            <ReactNativeElements.Divider style={{ borderTop: 1, marginTop: 10, marginBottom: 10 }} />
              {checkBoxes}
            </View>
          </ScrollView>
          <View flexDirection='row' justifyContent='space-between'>
            <Button containerStyle={{backgroundColor: '#fff', padding: 5, margin: 7, borderRadius: 6}} onPress = {() => this.filterRecipes(navigation.getParam('categoryTitle'))}  >
              <Text style={{color: '#f27676',fontWeight: '500', fontSize: 16}}> APPLY </Text>
            </Button>
            <Button containerStyle={{backgroundColor: '#fff', padding: 5, margin: 7, borderRadius: 6}} onPress = {() => this.setState({sortArray: this.initial.sortArray, checkBox: [Array(4).fill(false), Array(7).fill(false), Array(9).fill(false),
               Array(8).fill(false), Array(22).fill(false)]})}  >
              <Text style={{color: '#f27676',fontWeight: '500', fontSize: 16}}> RESET </Text>
            </Button>
          </View>
        </ReactNativeElements.Overlay>
        <FooterTabIcon navigation={navigation}/>
			</Container>
		)
	}
}
