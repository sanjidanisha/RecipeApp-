import React, { Component } from 'react';
import { Drawer, Right, Body, Title, Icon, Button, Container, Text, Header, Content, Left, View} from 'native-base';

export default class Sidebar extends Component {
  render() {
    const { navigation } = this.props;
    return (

      <Content style={{ backgroundColor: '#FFFFFF', width: 200 }}>
        <Button style={{ marginTop: 50 }} iconLeft light onPress={() => this.props.navigation.navigate('Home')} navigation={navigation}>
          <Icon name='home' />
          <Text>Home</Text>
          </Button>
        <Button iconLeft light onPress={() => this.props.navigation.navigate('Recipe')} navigation={navigation}>
           <Icon name='people' />
          <Text>My Recipes</Text>
          </Button>
      </Content>

    )
  }
}

//
// class ButtonClick extends Component {
//
// 	render() {
// 		return (
//       <Content style={{ backgroundColor: '#FFFFFF' }}>
//         <Button style={{ fontSize: 12, color: 'black' }} onPress={() => this.props.navigation.navigate('Home')}>
//           <Text>Home</Text>
//           </Button>
//         <Button style={{ color: 'black' }} onPress={() => this.props.navigation.navigate('Recipe')}>
//           <Text>Recipe</Text>
//           </Button>
//       </Content>
//     )
// 	}
// }
//
// export default class Sidebar extends Component {
//
//   render () {
//     const { navigation } = this.props;
//         return (
//             <ButtonClick navigation={navigation}>
//             </ButtonClick>);
//       )
//   }
// }
