import React, { Component } from 'react';
import { AppRegistry, FlatList, Text, View, Image, Alert, AsyncStorage } from 'react-native';
import styles from '../styles/styles.js';
import flatListData from '../data/flatListData';
import Swipeout from "react-native-swipeout";
import Button from 'react-native-button';
import FooterTabIcon from '../components/FooterTabIcon';
import * as ReactNativeElements from 'react-native-elements';
import { Drawer, Icon, Container, Header, Content, Left, Body, Right } from 'native-base';

class FlatListItem extends React.Component {
  constructor (props) {
    super (props);
    this.state = {
      activeRowKey: null
    };
  }
  render() {
    const swipeSettings = {
      autoClose: true,
      onClose: (secId, rowId, direction) => {
        if(this.state.activeRowKey != null) {
          this.setState({ activeRowKey:null });
        }
      },
      onOpen: (secId, rowId, direction) => {
        this.setState({ activeRowKey: this.props.item.id });
      },
      right: [
        {
          onPress: () => {
            const deletingRow = this.state.activeRowKey;
            Alert.alert(
              'Alert',
              'Are you sure you want to delete?',
              [
                {text: 'No', onPress: () => console.log('Cancel Pressed'), style: 'cancel'},
                {text: 'Yes', onPress: () => {
                  this.props.tilesArr.splice(this.props.index, 1);
                  //Refresh FlatList
                  this.props.parentFlatList.refreshFlatList(deletingRow,this.props.tilesArr);
                }},
              ],
              { cancelable: true }
            );
          },
          text: 'Delete', type: 'delete'
        }
      ],
      rowId: this.props.index,
      sectionId: 1
    };
    return (
      <Swipeout {...swipeSettings}>
        <Button onPress={() => this.props.navigation.navigate('Card',{navigateBack: 'Recipe',
        item: this.props.item,categoryArr: this.props.parentFlatList.state.categoryArr,
        isAll: true, currID:this.props.parentFlatList.state.currID })}>
          <View style={{
              flex: 1,
              flexDirection: 'row',
              justifyContent: 'center',
              alignItems: 'center',
              backgroundColor: this.props.index % 2 == 0 ? '#ddd' : 'white'
          }}>
              <Image
                  source={{uri: this.props.item.imageUrl}}
                  style={styles.allTile}>
              </Image>

              <View style={{
                  flex: 1,
                  flexDirection: 'column'
                  }}>
                  <Text style={styles.recipeTitleText}>{this.props.item.recipeTitle}{'\n'}</Text>
                  <Text style={styles.recipeDescText}>Prep Time: {this.props.item.prepTime} mins</Text>
                  <Text style={styles.recipeDescText}>Cook Time: {this.props.item.cookTime} mins</Text>
                  <Text style={styles.recipeDescText}>Total Time: {this.props.item.totalTime} mins</Text>
              </View>
              </View>
          </Button>
        </Swipeout>
    );
  }
}

export default class RecipeScreen extends Component {
  constructor(props) {
    super(props);
    this.state = ({
      deletedRowKey: null,
      tiles: []
    });
  }
  refreshFlatList = (deletedKey, tilesArr) => {
    AsyncStorage.getItem('CurrentUser',(err,currID) => {
      AsyncStorage.getItem('Favorites',(err,favorites) => {
        let orgFavorites = JSON.parse(favorites)
        let order = []
        for(var i = 0; i < tilesArr.length; i++){
          order.push(tilesArr[i].key)
        }
        orgFavorites[currID - 1] = order
        AsyncStorage.setItem('Favorites',JSON.stringify(orgFavorites))
        this.setState((prevState) => {
          return {
            deletedRowKey: deletedKey,
            tiles: tilesArr,
            categoryArr: [],
            currID: ''
          };
        });
      })
    })
  }
  componentWillMount(){
    let allArr = []
    allArr = allArr.concat(flatListData[0].Appetizers,flatListData[0].Breakfast,flatListData[0].Lunches,flatListData[0].Dinners,
		flatListData[0].MainDishes,flatListData[0].SideDishes,flatListData[0].Salads,flatListData[0].Grilling,flatListData[0].SousVide,
		flatListData[0].CrockPot,flatListData[0].SaucesAndDressing,flatListData[0].SoupsAndStews,flatListData[0].Drinks,flatListData[0].Others)
    let order = []
    AsyncStorage.getItem('CurrentUser',(err,currID) => {
      AsyncStorage.getItem('Users',(err,user) => {
        AsyncStorage.getItem('Favorites',(err,favorites) => {
          order = JSON.parse(favorites)[currID-1]
          let tiles = []
          for(var i = 0; i < order.length; i++){
            tiles.push(allArr[order[i]])
          }
          this.setState({tiles: tiles, categoryArr: allArr, currID: currID})
        })
      })
    })
  }
  render(){
    const {navigation} = this.props;
		return (
			<Container>
        <Header>
          <Left>
          </Left>
          <Body>
             <Image style={{width: 120, height: 42}} source={require('../images/PureWow_logo.png')} />
          </Body>
          <Right>
          </Right>
        </Header>
          <View style={{flex: 1}}>
            <View style = {{alignItems:"center"}}>
              <Text style = {styles.titleText}>FAVORITES</Text>
            </View>
            <ReactNativeElements.Divider style={{ borderTop: 1, marginTop: 10, marginBottom: 10 }} />
              <FlatList
                  data={this.state.tiles}
                  renderItem={({item, index}) =>{
                      return (
                          <FlatListItem navigation={navigation} item={item} index={index} parentFlatList={this} tilesArr={this.state.tiles}>

                          </FlatListItem>);
                  }}
              >
              </FlatList>
          </View>
          <FooterTabIcon navigation={navigation}/>
			</Container>
		)
	}
}
