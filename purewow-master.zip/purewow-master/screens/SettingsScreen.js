import React, { Fragment, Component } from 'react';
import { AppRegistry, ScrollView, AsyncStorage, Alert, StyleSheet, FlatList, View, ImageBackground, Text, KeyboardAvoidingView, Image } from 'react-native';
import homeData from '../data/homeData';
import dummyData from '../data/dummyData';
import styles from '../styles/styles.js';
import * as ReactNativeElements from 'react-native-elements';
import Button from 'react-native-button';
import FooterTabIcon from '../components/FooterTabIcon';
import FlipToggle from 'react-native-flip-toggle-button';
// import Sidebar from './Sidebar';
import { Drawer, Icon, Container, Header, Content, Left, Body, Right } from 'native-base';

export default class SettingsScreen extends Component {
	constructor(props){
		super(props);
		this.state = {
			measurementOverlay: false,
			reminderToggle: false,
			gramsToggle: true,
			feedbackText:'',
			currID: ''
		}
	}
	sendHandleClick(){
		this.setState({feedbackText:''})
		Alert.alert('Message Sent')
	}
	componentWillMount(){
		AsyncStorage.getItem('CurrentUser',(err,result) => {
			this.setState({currID: result})
		})
	}
	render(){
		const { navigation } = this.props;
		let currID = navigation.getParam('currID')
		const dummyText = "PureWow is an American digital " +
		"media company that publishes women's lifestyle content. " +
			"Acquired by serial entrepreneur Gary Vaynerchuk in 2017 " +
			 "as part of The Gallery, PureWow tailors lifestyle topics for " +
			  "Millennials and Generation X, including fashion, beauty"+
				", home decor, recipes, entertainment, travel, technology, literature" +
				", and money."
		return (
			<Container>
				<Header>
          <Left>
          </Left>
          <Body>
            <Image style={{width: 120, height: 42}} source={require('../images/PureWow_logo.png')} />
          </Body>
					<Right/>
				</Header>
				<KeyboardAvoidingView behavior="padding" style = {{flex:1}}>
					<View style = {{alignItems:"center"}}>
						<Text style = {styles.titleText}>SETTINGS</Text>
					</View>
					<ReactNativeElements.Divider style={{ backgroundColor: 'black', height: 1.5}}/>
					<ScrollView>
						<View>
							<View>
								<Text style={styles.settingsFirstTitleText}>Change Measurements</Text>
								<View>
									<View alignSelf='center' flexDirection='row' justifyContent='space-between' width={300}>
										<Button onPress={() => this.setState({gramsToggle: !this.state.gramsToggle})}>
											{
												this.state.gramsToggle ?
												<Text style={styles.settingsContentText}>Ounces</Text> :
												<Text style={styles.settingsBoldText}>Ounces</Text>
											}
										</Button>
										<FlipToggle
											value={this.state.gramsToggle}
											buttonWidth={40}
											buttonHeight={15}
											buttonRadius={30}
											sliderWidth={20}
											sliderHeight={15}
											sliderRadius={50}
											buttonOnColor='green'
											buttonOffColor='green'
											onToggle={(newState) => this.setState({gramsToggle: !this.state.gramsToggle})} />
										<Button onPress={() => this.setState({gramsToggle: !this.state.gramsToggle})}>
											{
												this.state.gramsToggle ?
												<Text style={styles.settingsBoldText}>Grams</Text> :
												<Text style={styles.settingsContentText}>Grams</Text>
											}
										</Button>
									</View>
								</View>
							</View>
							<View>
								<Text style={styles.settingsTitleText}>Reminders</Text>
								<View alignSelf='center' flexDirection='row' justifyContent='space-between' width={300}>
									<Button onPress={() => this.setState({reminderToggle: !this.state.reminderToggle})}>
									{
										this.state.reminderToggle ?
										<Text style={styles.settingsContentText}>On</Text> :
										 <Text style={styles.settingsContentText}>Off</Text>
									}
									</Button>
									<FlipToggle
										value={this.state.reminderToggle}
										buttonWidth={40}
								    buttonHeight={15}
								    buttonRadius={30}
								    sliderWidth={20}
								    sliderHeight={15}
								    sliderRadius={50}
										buttonOnColor='green'
										buttonOffColor='grey'
										onToggle={(newState) => this.setState({reminderToggle: !this.state.reminderToggle})} />
								</View>
							</View>
							<View>
								<Text style={styles.settingsTitleText}>About Us</Text>
								<View>
									<Text style={styles.settingsContentText}>{dummyText}</Text>
								</View>
							</View>
							<View>
								<Text style={styles.settingsTitleText}>Contact Us</Text>
								<View>
									<View flexDirection='row'>
										<Text style={styles.settingsBoldText}>
											Telephone #:
										</Text>
										<Text style={styles.settingsContentText}>
											212-555-9999
										</Text>
									</View>
									<View flexDirection='row'>
										<Text style={styles.settingsBoldText}>
											Email:
										</Text>
										<Text style={styles.settingsContentText}>
											pwrecipes@purewow.com
										</Text>
									</View>
								</View>
							</View>
							<View>
								<Text style={styles.settingsTitleText}>Feedback</Text>
								<ReactNativeElements.Input
								  placeholder='Type here'
								  shake={true}
									containerStyle={{width:350, marginLeft:5}}
									inputContainerStyle={{height:50, borderColor:'#000', borderWidth:1}}
									inputStyle={{fontSize:16, fontFamily:'Arial'}}
									multiline={true}
									value={this.state.feedbackText}
									onChangeText={(text) => this.setState({feedbackText:text})}
								/>
							</View>
							<View flexDirection='row' justifyContent='space-between' width={340} alignSelf='center' marginTop={4}>
								<Button onPress={() => this.setState({feedbackText:''})}
									containerStyle={{backgroundColor: '#fff', padding: 5, margin: 7, borderRadius: 6}}>
									<Text style={{color: '#000',fontWeight: '500', fontSize: 16}}>Cancel</Text>
								</Button>
								<Button onPress={() => this.sendHandleClick()}
									containerStyle={{backgroundColor: '#fff', padding: 5, margin: 7, borderRadius: 6}}>
									<Text style={{color: '#000',fontWeight: '500', fontSize: 16}}>Send</Text>
								</Button>
							</View>
						</View>
					</ScrollView>
				</KeyboardAvoidingView>
				<FooterTabIcon navigation={navigation}/>
			</Container>
		)
	}
}
