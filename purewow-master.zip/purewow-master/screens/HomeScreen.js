import React, { Fragment, Component } from 'react';
import { AppRegistry, Alert, AsyncStorage, ScrollView, StyleSheet, FlatList, View, Image ,ImageBackground, Text } from 'react-native';
import homeData from '../data/homeData';
import flatListData from '../data/flatListData';
import styles from '../styles/styles.js';
import { List, ListItem } from 'react-native-elements';
import Button from 'react-native-button';
import FooterTabIcon from '../components/FooterTabIcon';
// import Sidebar from './Sidebar';
import { Drawer, Icon, Container, Header, Content, Left, Body, Right } from 'native-base';


class HomeElement extends Component {
	render() {
		// let sortArray = new Array(flatListData[0].Appetizers.length);
		let title = this.props.item.categoryTitles
		let sortArr = []
		let arr = []
		let isAll= false
		let length
		let soup, sauce = false
		if(title === "All Recipes"){
			arr = this.props.arrAll
			length = arr.length
			isAll = true
		}else if(title === "Appetizers"){
		 	length = flatListData[0].Appetizers.length
			arr = flatListData[0].Appetizers
		}else if(title === "Breakfast"){
			length = flatListData[0].Breakfast.length
			arr = flatListData[0].Breakfast
		}else if(title === "Lunches"){
			length = flatListData[0].Lunches.length
			arr = flatListData[0].Lunches
		}else if(title === "Dinners"){
			length = flatListData[0].Dinners.length
			arr = flatListData[0].Dinners
		}else if(title === "Main Dishes"){
			length = flatListData[0].MainDishes.length
			arr = flatListData[0].MainDishes
		}else if(title === "Side Dishes"){
			length = flatListData[0].SideDishes.length
			arr = flatListData[0].SideDishes
		}else if(title === "Salads"){
			length = flatListData[0].Salads.length
			arr = flatListData[0].Salads
		}else if(title === "Grilling"){
			length = flatListData[0].Grilling.length
			arr = flatListData[0].Grilling
		}else if(title === "Sous Vide"){
			length = flatListData[0].SousVide.length
			arr = flatListData[0].SousVide
		}else if(title === "Crock Pot"){
			length = flatListData[0].CrockPot.length
			arr = flatListData[0].CrockPot
		}else if(title === "Sauces"){
			length = flatListData[0].SaucesAndDressing.length
			arr = flatListData[0].SaucesAndDressing
			sauce = true
		}else if(title === "Soups & Stews"){
			length = flatListData[0].SoupsAndStews.length
			arr = flatListData[0].SoupsAndStews
			soup = true
		}else if(title === "Drinks"){
			length = flatListData[0].Drinks.length
			arr = flatListData[0].Drinks
		}else if(title === "Others"){
			length = flatListData[0].Others.length
			arr = flatListData[0].Others
		}
		// for(var i = 0; i < arr.length; i++){
		// 	sortArr.push(i)
		// }
		sortArr = Array.apply(null, {length: length}).map(Number.call, Number)
		if(this.props.item.key < 15)
		return (
        <View>
          <Button onPress={() => this.props.navigation.navigate('Filter',{categoryTitle: title,
					categoryArr: arr, sortArr: sortArr, key: this.props.item.key, soup: soup, sauce: sauce, isAll: isAll,
					currID: this.props.navigation.getParam('currID') })}>
            <ImageBackground source={{uri: this.props.item.imageUrl}}
             style={styles.homeTile}>
					 		<View width='100%'>
            		<Text style={styles.homeText}>{this.props.item.categoryTitles.toUpperCase()}</Text>
							</View>
           </ImageBackground>
          </Button>
        </View>
    );
		else return(
			<View>
				<Button onPress={() => this.props.navigation.navigate('All',{categoryTitle: title,
				categoryArr: arr, sortArr: sortArr, isAll: isAll, currID: this.props.navigation.getParam('currID') })}>
					<ImageBackground source={{uri: this.props.item.imageUrl}}
					 style={styles.homeFirstTile}>
					<Text style={styles.homeText}>{this.props.item.categoryTitles.toUpperCase()}</Text>
				 </ImageBackground>
				</Button>
			</View>
		);
	}
}

export default class HomeScreen extends Component {
	constructor(props){
		super(props);
		this.state = {
			currID: ''
		}
	}
	componentWillMount(){
		AsyncStorage.getItem('CurrentUser',(err,result) => {
			this.setState({currID: result})
		})
	}
	render(){
		const { navigation } = this.props;
		let currID = navigation.getParam('currID')
		let arrAll = []
		arrAll = arrAll.concat(flatListData[0].Appetizers,flatListData[0].Breakfast,flatListData[0].Lunches,flatListData[0].Dinners,
		flatListData[0].MainDishes,flatListData[0].SideDishes,flatListData[0].Salads,flatListData[0].Grilling,flatListData[0].SousVide,
		flatListData[0].CrockPot,flatListData[0].SaucesAndDressing,flatListData[0].SoupsAndStews,flatListData[0].Drinks,flatListData[0].Others)
		return (
			<Container>
				<Header>
					<Left>
					</Left>
					<Body>
						<Image style={{width: 120, height: 42}} source={require('../images/PureWow_logo.png')} />
					</Body>
					<Right>
						<Text></Text>
					</Right>
				</Header>
				<View style = {{alignItems:"center", flex:1}}>
					<View height = {550}>
						<ScrollView>
							<HomeElement item={homeData[14]} index={14} navigation={navigation} arrAll={arrAll} />
							<FlatList
								numColumns={2}
								data={homeData}
								renderItem={({item, index}) =>{
									if (index < 14) return (
										<HomeElement item={item} index={index}
										navigation={navigation} arrAll={arrAll}/>);
							}} />
						</ScrollView>
					</View>
				</View>
				<FooterTabIcon navigation={navigation}/>
			</Container>
		)
	}
}
