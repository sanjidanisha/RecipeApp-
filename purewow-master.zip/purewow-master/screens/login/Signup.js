import React, { Component } from 'react';
import { StyleSheet, View, Image, Text, KeyboardAvoidingView, ImageBackground, TouchableOpacity } from 'react-native';
import Button from 'react-native-button';
import SignupForm from './SignupForm';

export default class Signup extends Component {
  render() {
    return (
        <KeyboardAvoidingView behavior="padding" style={styles.container}>
          <ImageBackground
            style={styles.imgBg}
            source={require('../../images/wings.png')}>
            <View style={styles.mainContainer}>
              <View style={styles.formContainer}>
                <SignupForm navigation={this.props.navigation} />
                <View style={styles.signupWrapper}>
                  <Text style={styles.signupText}>Already Have An Account?</Text>
                  <TouchableOpacity onPress={() => this.props.navigation.navigate('Login')} style={styles.buttonContainer}>
                    <Button style={styles.buttonText} onPress={() => this.props.navigation.navigate('Login')}>Login</Button>
                  </TouchableOpacity>
                </View>
              </View>
            </View>
          </ImageBackground>
        </KeyboardAvoidingView>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  mainContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(0,0,0,0.4)'
  },
  imgBg: {
    flex: 1
  },
  title: {
    color: '#fff',
    marginTop: 10,
    width: 200,
    fontSize: 15,
    textAlign: 'center'
  },
  loginText: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'center',
    marginBottom: 20
  },
  signupWrapper: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingBottom: 10
  },
  signupText: {
    color: '#fff',
    marginBottom: 10
  },
  buttonContainer: {
    backgroundColor: 'transparent',
    borderColor: '#fff',
    borderWidth: 1,
    paddingVertical: 10,
    paddingHorizontal: 10,
    width: 200,
    borderRadius: 10
  },
  buttonText: {
    textAlign: 'center',
    color: '#fff',
    fontWeight: '700'
  }
});
