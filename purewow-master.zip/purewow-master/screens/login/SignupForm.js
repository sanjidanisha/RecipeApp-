import React, { Component } from 'react';
import { StyleSheet, View, Alert, TextInput, Text, TouchableOpacity, StatusBar, AsyncStorage } from 'react-native';
import userData from '../../data/userData';
import { createStackNavigator } from 'react-navigation';


/**
ASYNC KEYS
test, test2, test3, user

test3 - index
test4 - user array

**/


export default class SignupForm extends Component {
  constructor(props){
    super(props);
    this.state = {
      name: '',
      email: '',
      password: '',
      confirmPassword: '',
      errorPassword: false,
      errorEmail: false,
      errorIncomplete: false,
      success: false,
    }
  }
  createUser(){
    let newUser = Object();
    let passwordMatch = false;
    let uniqueEmail = false;
    let complete = true;
    this.setState({error: false})
    if(this.state.password === this.state.confirmPassword){
      passwordMatch = true;
    }
    AsyncStorage.getItem('Users',(err,users) => {
      let match = true
      let emailCheck = []
      AsyncStorage.getItem('ID',(err,index) => {
          for(var i = 0; i < index;i++){
            emailCheck.push(JSON.parse(users)[i])
          }
          // Alert.alert("Emails: " + emailCheck[0].email + " " + emailCheck.length)
          for(var i = 0; i < emailCheck.length; i++){
            // Alert.alert('checking')
            if(this.state.email.toLowerCase() == emailCheck[i].email.toLowerCase()){
              // Alert.alert('error')
              match = false;
            }
          }
          uniqueEmail = match
          // Alert.alert('Unique Email AFTER LOOP: ' + uniqueEmail)
          if(this.state.name.length == 0 || this.state.email.length == 0 || this.state.password.length == 0){
            complete = false;
          }
          if(passwordMatch && uniqueEmail && complete){
            newUser.name = this.state.name
            newUser.email = this.state.email
            newUser.password = this.state.password
            newUser.favoriteRecipes = []
            let users = []
            AsyncStorage.getItem('ID', (err,result) => {
              let nextIndex = parseInt(result)+1
              newUser.id = nextIndex
              AsyncStorage.setItem('ID', JSON.stringify(nextIndex))
            })
            AsyncStorage.getItem('Users',(err,result) => {
              users = JSON.parse(result)
              users.push(newUser)
              AsyncStorage.setItem('Users', JSON.stringify(users))
            })
            AsyncStorage.getItem('Favorites',(err,result) => {
              let orgFavorites = JSON.parse(result)
              orgFavorites.push([])
              AsyncStorage.setItem('Favorites',JSON.stringify(orgFavorites))
            })
            this.props.navigation.navigate('Login')
          }else{
            if(!uniqueEmail){
              this.setState({errorEmail: true})
            }else{
              this.setState({errorEmail: false})
            }
            if(!passwordMatch){
              this.setState({errorPassword: true})
            }else{
              this.setState({errorPassword: false})
            }
            if(!complete){
              this.setState({errorIncomplete: true})
            }else{
              this.setState({errorIncomplete: false})
            }
          }
        })
      });
    // Alert.alert(AsyncStorage.getItem('user', (err, result) => {
    //   console.log(result);
    // })
    // )
  }
  render() {
    return (
        <View style={styles.container}>
          <StatusBar
            barStyle="light-content"
          />
          <View>
            {
              this.state.errorPassword ?
              <Text style={styles.incorrectEntry}>*Passwords do not match.</Text> :
              <Text/>
            }
            {
              this.state.errorEmail ?
              <Text style={styles.incorrectEntry}>*This email is already in use.</Text> :
              <Text/>

            }
            {
              this.state.errorIncomplete ?
              <Text style={styles.incorrectEntry2}>*Please fill out all the fields.</Text> :
              <Text/>
            }
            {
              this.state.success ?
              <Text style={styles.success }>Sign Up Successful!</Text> : null
            }
          </View>
          <TextInput
            value={this.state.name}
            onChangeText={(text) => this.setState({name:text})}
            placeholder="Name"
            placeholderTextColor="rgba(255,255,255,0.7)"
            returnKeyType="next"
            onSubmitEditing={() => this.passwordInput.focus()}
            autoCapitalize="none"
            autoCorrect={false}
            style={styles.input}
          />
          <TextInput
            value={this.state.email}
            onChangeText={(text) => this.setState({email:text})}
            placeholder="Email"
            placeholderTextColor="rgba(255,255,255,0.7)"
            returnKeyType="next"
            onSubmitEditing={() => this.passwordInput.focus()}
            keyboardType="email-address"
            autoCapitalize="none"
            autoCorrect={false}
            style={styles.input}
          />
          <TextInput
            value={this.state.password}
            onChangeText={(text) => this.setState({password:text})}
            placeholder="Password"
            placeholderTextColor="rgba(255,255,255,0.7)"
            returnKeyType="next"
            secureTextEntry
            style={styles.input}
            ref={(input) => this.passwordInput = input}
          />
          <TextInput
            value={this.state.confirmPassword}
            onChangeText={(text) => this.setState({confirmPassword:text})}
            placeholder="Confirm Password"
            placeholderTextColor="rgba(255,255,255,0.7)"
            returnKeyType="go"
            secureTextEntry
            style={styles.input}
            ref={(input) => this.passwordInput = input}
          />
          <TouchableOpacity onPress={() => this.createUser()} style={styles.buttonContainer}>
            <Text style={styles.buttonText}>Sign Up</Text>
          </TouchableOpacity>
        </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    padding: 10,
    justifyContent: 'center',
    alignItems: 'center'
  },
  input: {
    height: 40,
    width: 300,
    backgroundColor: 'rgba(255,255,255,0.3)',
    marginBottom: 10,
    borderRadius: 10,
    color: '#fff',
    borderColor: '#fff',
    borderWidth: 1,
    paddingHorizontal: 10
  },
  buttonContainer: {
    backgroundColor: '#F06A6B',
    marginBottom: 20,
    paddingVertical: 15,
    paddingHorizontal: 10,
    width: 300,
    borderRadius: 10
  },
  buttonText: {
    textAlign: 'center',
    color: '#fff',
    fontWeight: '700'
  },
  incorrectEntry: {
    color: 'white',
    fontWeight: '400',
    textAlign:'center',
  },
  incorrectEntry2:{
    color: 'white',
    fontWeight: '400',
    textAlign:'center',
    padding: 10
  },
  success: {
    color: '#0f0',
    fontWeight: '400',
    textAlign:'center',
    padding: 5
  }
});
