import React, { Component } from 'react';
import { StyleSheet, View, TextInput, Text, TouchableOpacity, AsyncStorage,StatusBar, Alert } from 'react-native';
import Button from 'react-native-button';
import userData from '../../data/userData';
import { createStackNavigator } from 'react-navigation';


export default class LoginForm extends Component {
  constructor(props){
    super(props);
    this.state = {
      email: '',
      password: '',
      incorrectEntry: false,
    }
  }
  validEntry(){
    let userArr = []
    AsyncStorage.getItem('Users',(err,users) => {
      // Alert.alert(JSON.parse(result)[0])
      AsyncStorage.getItem('ID',(err,index) => {
          for(var i = 0; i < index;i++){
            userArr.push(JSON.parse(users)[i])
          }
          // Alert.alert(userArr)
          for(var i = 0; i < userArr.length; i++){
            if(this.state.email.toLowerCase() == userArr[i].email.toLowerCase() && this.state.password.toString() == userArr[i].password){
              AsyncStorage.setItem('CurrentUser',JSON.stringify(userArr[i].id))
              AsyncStorage.getItem('CurrentUser',(err,result) => {
                this.props.navigation.navigate('Home',{currID: result})
              })
            }
          }
        })
      })
      this.setState({incorrectEntry: true})
  }
  render() {
    return (
        <View style={styles.container}>
          <StatusBar
            barStyle="light-content"
          />
          {
            this.state.incorrectEntry ?
            <Text style={styles.incorrectEntry}>Incorrect Email/Password Combination</Text> :
            null
          }
          <TextInput
            value={this.state.email}
            onChangeText={(text) => this.setState({email:text})}
            placeholder="Email"
            placeholderTextColor="rgba(255,255,255,0.7)"
            returnKeyType="next"
            onSubmitEditing={() => this.passwordInput.focus()}
            keyboardType="email-address"
            autoCapitalize="none"
            autoCorrect={false}
            style={styles.input}
          />
          <TextInput
            value={this.state.password}
            onChangeText={(text) => this.setState({password:text})}
            placeholder="Password"
            placeholderTextColor="rgba(255,255,255,0.7)"
            returnKeyType='go'
            secureTextEntry
            style={styles.input}
            ref={(input) => this.passwordInput = input}
          />
          <TouchableOpacity style={styles.buttonContainer} onPress={() => this.validEntry()}>
            <Button style={styles.buttonText} onPress={() => this.validEntry()}>Login</Button>
          </TouchableOpacity>
        </View>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    padding: 10,
    justifyContent: 'center',
    alignItems: 'center'
  },
  input: {
    height: 40,
    width: 300,
    backgroundColor: 'rgba(255,255,255,0.3)',
    marginBottom: 10,
    borderRadius: 10,
    color: '#fff',
    borderColor: '#fff',
    borderWidth: 1,
    paddingHorizontal: 10
  },
  buttonContainer: {
    backgroundColor: '#F06A6B',
    paddingVertical: 15,
    paddingHorizontal: 10,
    width: 300,
    borderRadius: 10
  },
  buttonText: {
    textAlign: 'center',
    color: '#fff',
    fontWeight: '700'
  },
  incorrectEntry: {
    padding: 10,
    color: 'white',
    fontWeight: '400',
    textAlign:'center'
  }
});
