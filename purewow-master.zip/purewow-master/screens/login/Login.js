import React, { Component } from 'react';
import { StyleSheet, View, Image, AsyncStorage, Alert, TextInput, Text, KeyboardAvoidingView, ImageBackground, TouchableOpacity } from 'react-native';
import Button from 'react-native-button';
import {Overlay, Icon} from 'react-native-elements';
import userData from '../../data/userData';
import LoginForm from './LoginForm';

/**
  test3 carries index
  test4 carries array of users
  RESET
  let user = Object();
  user.name = 'Erik'
  user.email = 'erik@gmail.com'
  user.password = 12
  user.id = 1

  let users = []
  users.push(user)
  AsyncStorage.setItem('test3',JSON.stringify(1))
  AsyncStorage.setItem('test4',JSON.stringify(users))

  AsyncStorage.getItem('test3',(err,result) => {
  Alert.alert('Index: ' + result)
  })
  AsyncStorage.getItem('test4',(err,result) => {
  Alert.alert(JSON.parse(result))
  })

  DISPLAY DATA
  AsyncStorage.getItem('test3',(err,result) => {
  Alert.alert('Current ID: ' + result)
  })
  AsyncStorage.getItem('test4',(err,result) => {
  Alert.alert(JSON.parse(result))
  })
**/
// let user = Object();
// user.name = 'Erik'
// user.email = 'erik@gmail.com'
// user.password = '12'
// user.id = 1
// user.favoriteRecipes = [0,1,2,85]
// //
// let users = []
// let favorites = [[0,1,2,3]]
// users.push(user)
// AsyncStorage.setItem('ID',JSON.stringify(1))
// AsyncStorage.setItem('Users',JSON.stringify(users))
AsyncStorage.setItem('CurrentUser',JSON.stringify(''))
// AsyncStorage.setItem('Favorites',JSON.stringify(favorites))

// AsyncStorage.getItem('ID',(err,result) => {
// Alert.alert('Index: ' + result)
// })
// AsyncStorage.getItem('Users',(err,result) => {
// Alert.alert(JSON.parse(result))
// })
// AsyncStorage.getItem('CurrentUser',(err,result) => {
//   Alert.alert('CurrentUser: ' + result)
// })
// AsyncStorage.getItem('Favorites',(err,result) => {
//   Alert.alert('Favorites: ' + result)
// })


export default class Login extends Component {
  constructor(props){
    super(props);
    this.state = {
      forgotPasswordOverlay: false,
      forgotPasswordEmail: '',
      noKnownEmail: false,
    }
  }
  forgotPassword(){
    let found = true;
    let userArr = []
    AsyncStorage.getItem('Users',(err,users) => {
      AsyncStorage.getItem('ID',(err,index) => {
        for(var i = 0; i < index;i++){
          userArr.push(JSON.parse(users)[i])
        }
        for(var i = 0; i < userArr.length;i++){
          if(this.state.forgotPasswordEmail.toLowerCase() == userArr[i].email.toLowerCase()){
            found = false
            Alert.alert("Your password: " + userArr[i].password)
          }
        }
        this.setState({noKnownEmail: found})
      })
    })
  }
  render() {
    return (
        <KeyboardAvoidingView behavior="padding" style={styles.container}>
          <ImageBackground
            style={styles.imgBg}
            source={require('../../images/wings.png')}>
            <View style={styles.mainContainer}>
              <View style={styles.logoContainer}>
                <Image
                  style={styles.logo}
                  source={require('../../images/purewow.png')}/>
                <Text style={styles.title}>Recipe App</Text>
              </View>
              <View style={styles.formContainer}>
                <Text style={styles.loginText}>Login or Create Your New Account</Text>
                <LoginForm navigation={this.props.navigation} />
                <View style={styles.signupWrapper}>
                  <Button onPress={() => this.setState({forgotPasswordOverlay: true})}>
                    <Text style={styles.passwordText}>Forgot Your Password?</Text>
                  </Button>
                  <Text style={styles.signupText}>Don{`'`}t Have An Account?</Text>
                  <TouchableOpacity onPress={() => this.props.navigation.navigate('Signup')} style={styles.buttonContainer}>
                    <Button style={styles.buttonText} onPress={() => this.props.navigation.navigate('Signup')}>Sign Up</Button>
                  </TouchableOpacity>
                </View>
              </View>
              <Overlay
                isVisible={this.state.forgotPasswordOverlay}
                windowBackgroundColor="rgba(0, 0, 0, .5)"
                overlayBackgroundColor="white"
                width= {360}
                height= {160}
                containerStyle={{alignItems: 'center'}}
                >
                <View alignItems='flex-end' margin={5}>
                  <Button onPress = {() => this.setState({forgotPasswordOverlay: false})} >
                    <Icon name='close' />
                  </Button>
                </View>
                <View>
                  <Text>Input your email</Text>
                </View>
                <View marginLeft={5} marginTop={5}>
                  <TextInput
                  placeholder='Type here'
                  containerStyle={{width:350, marginLeft:5}}
                  borderWidth={1}
                  height={40}
                  borderColor='#000'
                  inputStyle={{fontSize:16, fontFamily:'Arial'}}
                  value={this.state.forgotPasswordEmail}
                  onChangeText={(text) => this.setState({forgotPasswordEmail:text})}
                  />
                </View>
                <View flexDirection='row' justifyContent='space-between' marginTop={5}>
                  {
                    this.state.noKnownEmail ?
                    <Text color='white' style={styles.forgotPasswordError}>
                      There are no accounts with that email.
                    </Text> : <Text/>
                  }
                  <Button onPress={() => this.forgotPassword()}
  									containerStyle={styles.forgotPasswordSubmitButton}>
                    <Text>Submit</Text>
                  </Button>
                </View>
              </Overlay>
            </View>
          </ImageBackground>
        </KeyboardAvoidingView>
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1
  },
  imgBg: {
    flex: 1
  },
  mainContainer: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.4)'
  },
  logoContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 50
  },
  logo: {
    width: 150,
    height: 50
  },
  title: {
    color: '#fff',
    marginTop: 10,
    width: 200,
    fontSize: 20,
    textAlign: 'center'
  },
  signupWrapper: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingBottom: 10
  },
  loginText: {
    color: '#fff',
    fontSize: 20,
    textAlign: 'center',
    marginBottom: 20
  },
  passwordText: {
    color: '#fff',
    paddingBottom: 10
  },
  signupText: {
    color: '#fff',
    marginTop: 30,
    marginBottom: 10
  },
  formContainer: {
    flex: 1,
    marginTop: 75
  },
  buttonContainer: {
    backgroundColor: 'transparent',
    borderColor: '#fff',
    borderWidth: 1,
    paddingVertical: 10,
    paddingHorizontal: 10,
    width: 200,
    borderRadius: 10
  },
  buttonText: {
    textAlign: 'center',
    color: '#fff',
    fontWeight: '700'
  },
  forgotPasswordSubmitButton: {
    backgroundColor: '#fff',
    padding: 5,
    margin: 7,
    borderRadius: 6
  },
  forgotPasswordError:{
    backgroundColor: '#fff',
    padding: 5,
    margin: 7,
    borderRadius: 6,
    color: '#f00'
  }
});
