import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  homeContainer: {
    flexWrap: 'wrap',
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
    marginTop: 20,
    flex: 1,
  },

  homeTile: {
    flex: 1,
    height: 130,
    width: 177,
    margin: 3,
    marginBottom: 14,
    marginRight: 10,
    textAlign: 'center',
    alignItems: 'center',
    justifyContent: 'flex-end',
  },

  homeFirstTile: {
    flex: 1,
    height: 130,
    width: 366,
    margin: 3,
    marginBottom: 14,
    textAlign: 'center',
    alignItems: 'center',
    justifyContent: 'flex-end',
  },

  homeText: {
    color: '#000',
    fontSize: 16,
    backgroundColor: '#fff',
    opacity: 0.8,
    paddingTop: 5,
    paddingBottom: 5,
    width: '100%',
    textAlign: 'center',
    fontWeight: '400',
    fontFamily: 'Arial'
  },

  titleText: {
    color: '#000',
    fontSize: 18,
    alignItems: 'center',
    fontWeight: '400',
    fontFamily: 'Arial',
    paddingTop: 10,
    paddingBottom: 0,
    justifyContent: 'center'
  },

  recipeTitleText: {
    textAlign: 'left',
    fontWeight: '400',
    fontFamily: 'Arial',
    paddingRight: 5,
    fontSize: 18
  },

  recipeDescText: {
    textAlign: 'left',
    fontFamily: 'Arial',
    fontSize: 14,
    paddingTop: 2
  },

  allTile:{
    flex: 1,
    height: 130,
    width: 180,
    marginTop: 4,
    marginBottom: 5,
    marginLeft: 2,
    marginRight: 2
  },

  headline: {
    fontSize: 14,
    backgroundColor: 'rgb(0,0,0)',
    color: 'white',
    fontWeight: '500',
    fontFamily: 'Arial'
  },

  categoryText: {
    color: '#000',
    fontSize: 24,
    fontFamily: 'Arial',
    textAlign: 'left',
    marginLeft: 10,
    marginBottom: 10
  },

  wholeTile: {
    marginTop: 10
  },

  textTile: {
    flex: 1,
    height: 110,
    width: 185,
    justifyContent: 'flex-start',
    paddingTop: 5
  },

  notFoundText:{
    fontSize: 18,
    fontFamily: 'Arial',
  },

  recipeBackgroundOverlay:{
    width: 380
  },

  settingsFirstTitleText:{
    fontSize: 18,
    fontWeight: 'bold',
    fontFamily: 'Arial',
    marginTop: 5,
    marginLeft: 2,
    marginBottom: 5
  },

  settingsTitleText:{
    fontSize: 18,
    fontWeight: 'bold',
    fontFamily: 'Arial',
    marginTop: 20,
    marginLeft: 2,
    marginBottom: 5
  },

  settingsContentText:{
    fontSize: 16,
    fontWeight: '300',
    fontFamily: 'Arial',
    marginLeft: 5,
  },

  settingsBoldText:{
    fontSize: 16,
    fontWeight: 'bold',
    fontFamily: 'Arial',
    marginLeft: 5,
  },

  error:{
    color: 'red',
    fontSize: 16,
    fontWeight: '300',
    fontFamily: 'Arial'
  },

  tileBackground:{
    width:380,
  }

});
